import { Router, type IRouter } from "express";
import healthRouter from "./health";
import clonerRouter from "./cloner";
import openaiConversationsRouter from "./openai-conversations";

const router: IRouter = Router();

router.use(healthRouter);
router.use(clonerRouter);
router.use(openaiConversationsRouter);

export default router;
