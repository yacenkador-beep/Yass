import { Router } from "express";
import { chromium } from "playwright";
import { db } from "@workspace/db";
import { cloneJobs } from "@workspace/db";
import { eq, desc, count } from "drizzle-orm";
import {
  CreateCloneJobBody,
  GetCloneJobParams,
  DeleteCloneJobParams,
  ExportCloneJobParams,
} from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";
import { logger } from "../lib/logger";

const router = Router();

// GET /cloner/jobs
router.get("/cloner/jobs", async (req, res) => {
  try {
    const jobs = await db
      .select()
      .from(cloneJobs)
      .orderBy(desc(cloneJobs.createdAt));
    res.json(jobs.map(formatJob));
  } catch (err) {
    req.log.error({ err }, "Failed to list clone jobs");
    res.status(500).json({ error: "Failed to list clone jobs" });
  }
});

// POST /cloner/jobs
router.post("/cloner/jobs", async (req, res) => {
  const parsed = CreateCloneJobBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid request body" });
  }

  const { url } = parsed.data;

  // Validate URL
  try {
    new URL(url);
  } catch {
    return res.status(400).json({ error: "Invalid URL provided" });
  }

  try {
    const [job] = await db
      .insert(cloneJobs)
      .values({ url, status: "pending" })
      .returning();

    res.status(201).json(formatJob(job));

    // Run analysis in background
    processCloneJob(job.id, url).catch((err) => {
      logger.error({ err, jobId: job.id }, "Clone job failed");
    });
  } catch (err) {
    req.log.error({ err }, "Failed to create clone job");
    res.status(500).json({ error: "Failed to create clone job" });
  }
});

// GET /cloner/jobs/:id
router.get("/cloner/jobs/:id", async (req, res) => {
  const parsed = GetCloneJobParams.safeParse({ id: req.params.id });
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid job ID" });
  }

  try {
    const [job] = await db
      .select()
      .from(cloneJobs)
      .where(eq(cloneJobs.id, parsed.data.id));

    if (!job) {
      return res.status(404).json({ error: "Job not found" });
    }

    res.json(formatJob(job));
  } catch (err) {
    req.log.error({ err }, "Failed to get clone job");
    res.status(500).json({ error: "Failed to get clone job" });
  }
});

// DELETE /cloner/jobs/:id
router.delete("/cloner/jobs/:id", async (req, res) => {
  const parsed = DeleteCloneJobParams.safeParse({ id: req.params.id });
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid job ID" });
  }

  try {
    const [deleted] = await db
      .delete(cloneJobs)
      .where(eq(cloneJobs.id, parsed.data.id))
      .returning();

    if (!deleted) {
      return res.status(404).json({ error: "Job not found" });
    }

    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete clone job");
    res.status(500).json({ error: "Failed to delete clone job" });
  }
});

// GET /cloner/jobs/:id/export
router.get("/cloner/jobs/:id/export", async (req, res) => {
  const parsed = ExportCloneJobParams.safeParse({ id: req.params.id });
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid job ID" });
  }

  try {
    const [job] = await db
      .select()
      .from(cloneJobs)
      .where(eq(cloneJobs.id, parsed.data.id));

    if (!job) {
      return res.status(404).json({ error: "Job not found" });
    }

    if (!job.generatedHtml) {
      return res.status(400).json({ error: "Clone job not completed yet" });
    }

    const hostname = new URL(job.url).hostname.replace(/\./g, "_");
    res.json({
      html: job.generatedHtml,
      filename: `${hostname}_clone.html`,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to export clone job");
    res.status(500).json({ error: "Failed to export clone job" });
  }
});

// GET /cloner/stats
router.get("/cloner/stats", async (req, res) => {
  try {
    const jobs = await db.select().from(cloneJobs);
    const total = jobs.length;
    const completed = jobs.filter((j) => j.status === "completed").length;
    const failed = jobs.filter((j) => j.status === "failed").length;
    const pending = jobs.filter(
      (j) => j.status === "pending" || j.status === "analyzing" || j.status === "generating"
    ).length;

    res.json({ total, completed, failed, pending });
  } catch (err) {
    req.log.error({ err }, "Failed to get clone stats");
    res.status(500).json({ error: "Failed to get clone stats" });
  }
});

async function processCloneJob(jobId: number, url: string) {
  // Update to analyzing
  await db
    .update(cloneJobs)
    .set({ status: "analyzing", updatedAt: new Date() })
    .where(eq(cloneJobs.id, jobId));

  let browser;
  try {
    browser = await chromium.launch({
      executablePath:
        process.env["PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH"] ||
        "/home/runner/.cache/ms-playwright/chromium-1217/chrome-linux64/chrome",
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
    });
    const context = await browser.newContext({
      userAgent:
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    });
    const page = await context.newPage();

    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 30000 });
    await page.waitForTimeout(2000);

    // Extract design information
    const pageData = await page.evaluate(() => {
      const getColors = () => {
        const colors = new Set<string>();
        const elements = document.querySelectorAll("*");
        elements.forEach((el) => {
          const style = window.getComputedStyle(el);
          const bg = style.backgroundColor;
          const color = style.color;
          if (bg && bg !== "rgba(0, 0, 0, 0)" && bg !== "transparent") {
            colors.add(bg);
          }
          if (color && color !== "rgba(0, 0, 0, 0)") {
            colors.add(color);
          }
        });
        return Array.from(colors).slice(0, 20);
      };

      const getFonts = () => {
        const fonts = new Set<string>();
        const elements = document.querySelectorAll("*");
        elements.forEach((el) => {
          const style = window.getComputedStyle(el);
          fonts.add(style.fontFamily);
        });
        return Array.from(fonts).slice(0, 10);
      };

      const getSections = () => {
        const sections: string[] = [];
        const sectionSelectors = [
          "header",
          "nav",
          "main",
          "section",
          "footer",
          ".hero",
          ".features",
          ".pricing",
          ".testimonials",
          "[class*='hero']",
          "[class*='feature']",
          "[class*='pricing']",
        ];
        sectionSelectors.forEach((sel) => {
          const els = document.querySelectorAll(sel);
          if (els.length > 0) {
            sections.push(
              `${sel} (${els.length} found): ${Array.from(els)
                .slice(0, 2)
                .map((el) => el.textContent?.slice(0, 100))
                .join(" | ")}`
            );
          }
        });
        return sections.slice(0, 15);
      };

      const title = document.title;
      const description =
        document.querySelector('meta[name="description"]')?.getAttribute("content") ||
        document.querySelector("h1")?.textContent ||
        "";
      const h1s = Array.from(document.querySelectorAll("h1")).map(
        (el) => el.textContent?.trim()
      );
      const h2s = Array.from(document.querySelectorAll("h2"))
        .slice(0, 5)
        .map((el) => el.textContent?.trim());
      const navLinks = Array.from(
        document.querySelectorAll("nav a, header a")
      )
        .slice(0, 10)
        .map((a) => (a as HTMLAnchorElement).textContent?.trim());
      const bodyText = document.body.innerText.slice(0, 2000);

      return {
        title,
        description,
        h1s,
        h2s,
        navLinks,
        bodyText,
        colors: getColors(),
        fonts: getFonts(),
        sections: getSections(),
      };
    });

    await browser.close();
    browser = null;

    // Update status to generating
    await db
      .update(cloneJobs)
      .set({
        status: "generating",
        title: pageData.title,
        description: pageData.description?.slice(0, 500),
        colors: JSON.stringify(pageData.colors),
        fonts: JSON.stringify(pageData.fonts),
        sections: JSON.stringify(pageData.sections),
        updatedAt: new Date(),
      })
      .where(eq(cloneJobs.id, jobId));

    // Generate HTML with AI
    const systemPrompt = `You are an expert frontend developer. Generate a complete, beautiful, responsive HTML landing page that resembles the website at ${url}.

Use only HTML, CSS (inline <style> tag), and minimal vanilla JavaScript. Do not use external CSS frameworks or JavaScript libraries.

Create a modern, polished landing page based on the extracted website data provided. Match the color scheme, typography style, and content structure. Make it look professional and pixel-perfect.

IMPORTANT: Return ONLY the complete HTML document, starting with <!DOCTYPE html> and ending with </html>. No explanations, no markdown code blocks.`;

    const userPrompt = `Create a landing page clone based on this website data:

Title: ${pageData.title}
Description: ${pageData.description}

Headings:
H1: ${pageData.h1s.join(", ")}
H2: ${pageData.h2s.join(", ")}

Navigation items: ${pageData.navLinks.join(", ")}

Color palette extracted: ${pageData.colors.slice(0, 10).join(", ")}
Font families: ${pageData.fonts.slice(0, 5).join(", ")}

Sections detected: ${pageData.sections.join("\n")}

Content sample:
${pageData.bodyText}

Generate a complete, beautiful landing page that captures the essence and style of this website.`;

    const completion = await openai.chat.completions.create({
      model: "gpt-5.1",
      max_completion_tokens: 8000,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    });

    let generatedHtml =
      completion.choices[0]?.message?.content ?? "";

    // Strip any markdown code fences if AI wrapped it
    generatedHtml = generatedHtml
      .replace(/^```html\n?/i, "")
      .replace(/^```\n?/, "")
      .replace(/\n?```$/, "")
      .trim();

    await db
      .update(cloneJobs)
      .set({
        status: "completed",
        generatedHtml,
        updatedAt: new Date(),
      })
      .where(eq(cloneJobs.id, jobId));

    logger.info({ jobId }, "Clone job completed successfully");
  } catch (err) {
    if (browser) {
      await browser.close().catch(() => {});
    }
    logger.error({ err, jobId }, "Clone job processing failed");
    await db
      .update(cloneJobs)
      .set({
        status: "failed",
        errorMessage: err instanceof Error ? err.message : "Unknown error",
        updatedAt: new Date(),
      })
      .where(eq(cloneJobs.id, jobId));
  }
}

function formatJob(job: typeof cloneJobs.$inferSelect) {
  return {
    id: job.id,
    url: job.url,
    status: job.status,
    title: job.title,
    description: job.description,
    colors: job.colors,
    fonts: job.fonts,
    sections: job.sections,
    generatedHtml: job.generatedHtml,
    screenshotUrl: job.screenshotUrl,
    errorMessage: job.errorMessage,
    createdAt: job.createdAt.toISOString(),
    updatedAt: job.updatedAt.toISOString(),
  };
}

export default router;
