import { useGameStore } from "./store/gameStore";
import { MainMenu } from "./pages/MainMenu";
import { GaragePage } from "./pages/GaragePage";
import { LoadingScreen } from "./pages/LoadingScreen";
import { GameScene } from "./game/GameScene";

export default function App() {
  const { gameState } = useGameStore();

  if (gameState === "menu") return <MainMenu />;
  if (gameState === "garage") return <GaragePage />;
  if (gameState === "loading") return <LoadingScreen />;
  if (gameState === "playing" || gameState === "paused") return <GameScene />;

  return <MainMenu />;
}
