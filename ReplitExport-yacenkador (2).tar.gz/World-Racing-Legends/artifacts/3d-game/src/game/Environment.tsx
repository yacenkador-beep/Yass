import { useRef, useMemo } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useGameStore } from "../store/gameStore";

// Pre-calculated building positions
const BUILDINGS = (() => {
  const rng = (seed: number) => {
    let x = Math.sin(seed) * 10000;
    return x - Math.floor(x);
  };
  const b = [];
  for (let i = 0; i < 80; i++) {
    const side = i % 2 === 0 ? 1 : -1;
    const z = -200 + i * 6;
    const x = side * (35 + rng(i * 3.7) * 25);
    const h = 8 + rng(i * 1.3) * 40;
    const w = 6 + rng(i * 2.1) * 8;
    const d = 6 + rng(i * 4.5) * 8;
    const colorIndex = Math.floor(rng(i * 5.9) * 5);
    b.push({ x, z, h, w, d, colorIndex });
  }
  return b;
})();

const TREES = (() => {
  const rng = (seed: number) => { let x = Math.sin(seed) * 10000; return x - Math.floor(x); };
  const t = [];
  for (let i = 0; i < 60; i++) {
    const side = i % 2 === 0 ? 1 : -1;
    t.push({
      x: side * (28 + rng(i * 2.3) * 6),
      z: -180 + i * 7 + rng(i * 1.7) * 3,
      scale: 0.8 + rng(i * 3.1) * 0.6,
    });
  }
  return t;
})();

const STREET_LIGHTS = (() => {
  const l = [];
  for (let i = 0; i < 40; i++) {
    const side = i % 2 === 0 ? 1 : -1;
    l.push({ x: side * 22, z: -200 + i * 10 });
  }
  return l;
})();

const BUILDING_COLORS = [
  "#1a2035", "#0d1f3c", "#1f1a35", "#0d2a1f", "#2a1a0d"
];

function Building({ x, z, h, w, d, colorIndex }: { x: number; z: number; h: number; w: number; d: number; colorIndex: number }) {
  return (
    <group position={[x, h / 2, z]}>
      <mesh>
        <boxGeometry args={[w, h, d]} />
        <meshStandardMaterial
          color={BUILDING_COLORS[colorIndex]}
          metalness={0.3}
          roughness={0.7}
          emissive={BUILDING_COLORS[colorIndex]}
          emissiveIntensity={0.1}
        />
      </mesh>
      {/* Windows */}
      <mesh position={[0, 0, d / 2 + 0.05]}>
        <planeGeometry args={[w * 0.9, h * 0.9]} />
        <meshStandardMaterial
          color="#112233"
          emissive="#223344"
          emissiveIntensity={0.4}
          transparent
          opacity={0.8}
        />
      </mesh>
    </group>
  );
}

function Tree({ x, z, scale }: { x: number; z: number; scale: number }) {
  return (
    <group position={[x, 0, z]} scale={scale}>
      <mesh position={[0, 1.5, 0]}>
        <cylinderGeometry args={[0.2, 0.4, 3, 6]} />
        <meshStandardMaterial color="#3d2b1f" roughness={1} />
      </mesh>
      <mesh position={[0, 4, 0]}>
        <coneGeometry args={[2, 4, 8]} />
        <meshStandardMaterial color="#1a4a1a" roughness={0.9} />
      </mesh>
      <mesh position={[0, 6.5, 0]}>
        <coneGeometry args={[1.4, 3, 8]} />
        <meshStandardMaterial color="#1e5a1e" roughness={0.9} />
      </mesh>
    </group>
  );
}

function StreetLight({ x, z }: { x: number; z: number }) {
  const { timeOfDay } = useGameStore();
  const isNight = timeOfDay === "night";
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 4, 0]}>
        <cylinderGeometry args={[0.08, 0.12, 8, 6]} />
        <meshStandardMaterial color="#555" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[x > 0 ? -1.5 : 1.5, 8.2, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 3, 6]} rotation={[0, 0, Math.PI / 2]} />
        <meshStandardMaterial color="#555" metalness={0.8} roughness={0.2} />
      </mesh>
      <pointLight
        position={[x > 0 ? -1.5 : 1.5, 8.5, 0]}
        intensity={isNight ? 3 : 0}
        distance={20}
        color="#ffe8a0"
      />
      <mesh position={[x > 0 ? -1.5 : 1.5, 8.5, 0]}>
        <sphereGeometry args={[0.3, 8, 8]} />
        <meshStandardMaterial
          color="#ffe8a0"
          emissive="#ffe8a0"
          emissiveIntensity={isNight ? 3 : 0.1}
        />
      </mesh>
    </group>
  );
}

function RainEffect() {
  const rainRef = useRef<THREE.Points>(null);
  const { weather } = useGameStore();

  const rainGeo = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    const count = 3000;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 200;
      positions[i * 3 + 1] = Math.random() * 80;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 200;
    }
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return geo;
  }, []);

  useFrame((_, delta) => {
    if (!rainRef.current || weather !== "rain") return;
    const pos = rainRef.current.geometry.attributes.position.array as Float32Array;
    for (let i = 0; i < pos.length; i += 3) {
      pos[i + 1] -= 40 * delta;
      if (pos[i + 1] < 0) pos[i + 1] = 80;
    }
    rainRef.current.geometry.attributes.position.needsUpdate = true;
  });

  if (weather !== "rain" && weather !== "storm") return null;

  return (
    <points ref={rainRef} geometry={rainGeo}>
      <pointsMaterial color="#aaccff" size={0.15} transparent opacity={0.6} />
    </points>
  );
}

export function Environment() {
  const { timeOfDay, weather } = useGameStore();
  const isNight = timeOfDay === "night";
  const isSunset = timeOfDay === "sunset";

  const skyColor = isNight ? "#020408" : isSunset ? "#1a0810" : "#0a0f1a";
  const ambientIntensity = isNight ? 0.3 : isSunset ? 0.6 : 1.0;
  const sunColor = isNight ? "#102040" : isSunset ? "#ff6030" : "#fffaee";

  return (
    <group>
      {/* Sky */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[500, 32, 32]} />
        <meshBasicMaterial color={skyColor} side={THREE.BackSide} />
      </mesh>

      {/* Lighting */}
      <ambientLight intensity={ambientIntensity} color={isNight ? "#102030" : "#ffffff"} />
      <directionalLight
        position={isNight ? [0, -100, 0] : isSunset ? [-200, 30, -100] : [100, 200, 100]}
        intensity={isNight ? 0.1 : isSunset ? 1.5 : 2.5}
        color={sunColor}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-near={0.5}
        shadow-camera-far={800}
        shadow-camera-left={-200}
        shadow-camera-right={200}
        shadow-camera-top={200}
        shadow-camera-bottom={-200}
      />
      {isNight && <hemisphereLight color="#102060" groundColor="#000010" intensity={0.5} />}

      {/* Road */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
        <planeGeometry args={[400, 400]} />
        <meshStandardMaterial color="#0d0d0d" roughness={0.85} metalness={0.05} />
      </mesh>

      {/* Main road surface with lane markings */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]}>
        <planeGeometry args={[20, 400]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.8} metalness={0.0} />
      </mesh>

      {/* Lane dividers */}
      {[-200, -150, -100, -50, 0, 50, 100, 150].map((z, i) => (
        <mesh key={i} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, z]}>
          <planeGeometry args={[0.3, 6]} />
          <meshStandardMaterial color="#ffee00" emissive="#ffee00" emissiveIntensity={0.5} />
        </mesh>
      ))}

      {/* Side roads */}
      {[-100, 0, 100].map((x, i) => (
        <mesh key={i} rotation={[-Math.PI / 2, 0, 0]} position={[x, 0.001, 0]}>
          <planeGeometry args={[200, 14]} />
          <meshStandardMaterial color="#151515" roughness={0.8} />
        </mesh>
      ))}

      {/* Sidewalks */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[13, 0.05, 0]}>
        <planeGeometry args={[6, 400]} />
        <meshStandardMaterial color="#333344" roughness={0.9} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[-13, 0.05, 0]}>
        <planeGeometry args={[6, 400]} />
        <meshStandardMaterial color="#333344" roughness={0.9} />
      </mesh>

      {/* Track barrier walls */}
      <mesh position={[10.5, 0.5, 0]}>
        <boxGeometry args={[0.5, 1, 400]} />
        <meshStandardMaterial color="#cc2200" emissive="#440000" emissiveIntensity={0.3} />
      </mesh>
      <mesh position={[-10.5, 0.5, 0]}>
        <boxGeometry args={[0.5, 1, 400]} />
        <meshStandardMaterial color="#cc2200" emissive="#440000" emissiveIntensity={0.3} />
      </mesh>

      {/* Buildings */}
      {BUILDINGS.map((b, i) => (
        <Building key={i} {...b} />
      ))}

      {/* Trees */}
      {TREES.map((t, i) => (
        <Tree key={i} {...t} />
      ))}

      {/* Street lights */}
      {STREET_LIGHTS.map((l, i) => (
        <StreetLight key={i} {...l} />
      ))}

      {/* Neon signs */}
      {[-60, 0, 60, 120, -120].map((z, i) => (
        <group key={i} position={[i % 2 === 0 ? 40 : -40, 8, z]}>
          <mesh>
            <boxGeometry args={[8, 2, 0.2]} />
            <meshStandardMaterial
              color={["#ff0040", "#00ffaa", "#ff8800", "#0088ff", "#ff00ff"][i]}
              emissive={["#ff0040", "#00ffaa", "#ff8800", "#0088ff", "#ff00ff"][i]}
              emissiveIntensity={isNight ? 3 : 0.5}
            />
          </mesh>
        </group>
      ))}

      {/* Start/Finish line */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
        <planeGeometry args={[20, 2]} />
        <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.5} />
      </mesh>

      {/* Fog */}
      {(weather === "rain" || weather === "storm") && (
        <fog attach="fog" color="#334455" near={50} far={200} />
      )}
      {isNight && <fog attach="fog" color="#010208" near={80} far={300} />}
      {!isNight && weather === "clear" && <fog attach="fog" color="#0a0f1a" near={150} far={400} />}

      {/* Rain */}
      <RainEffect />

      {/* Ground plane extending far */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]} receiveShadow>
        <planeGeometry args={[2000, 2000]} />
        <meshStandardMaterial color="#0a0a0a" roughness={1} />
      </mesh>
    </group>
  );
}
