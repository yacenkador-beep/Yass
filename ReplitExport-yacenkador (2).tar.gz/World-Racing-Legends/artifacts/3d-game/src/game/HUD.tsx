import { useEffect, useRef, useState } from "react";
import { useGameStore } from "../store/gameStore";

function Speedometer({ speed, maxSpeed }: { speed: number; maxSpeed: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const cx = w / 2;
    const cy = h * 0.7;
    const r = w * 0.42;

    ctx.clearRect(0, 0, w, h);

    // Outer ring
    ctx.beginPath();
    ctx.arc(cx, cy, r + 4, Math.PI, 2 * Math.PI);
    ctx.strokeStyle = "rgba(255,255,255,0.1)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Background arc
    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI, 2 * Math.PI);
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.lineWidth = 14;
    ctx.stroke();

    // Speed arc
    const pct = Math.min(speed / maxSpeed, 1);
    const startAngle = Math.PI;
    const endAngle = Math.PI + pct * Math.PI;
    const gradient = ctx.createLinearGradient(0, 0, w, 0);
    gradient.addColorStop(0, "#00aaff");
    gradient.addColorStop(0.5, "#ff8800");
    gradient.addColorStop(1, "#ff2200");
    ctx.beginPath();
    ctx.arc(cx, cy, r, startAngle, endAngle);
    ctx.strokeStyle = gradient;
    ctx.lineWidth = 14;
    ctx.lineCap = "round";
    ctx.stroke();

    // Tick marks
    for (let i = 0; i <= 10; i++) {
      const angle = Math.PI + (i / 10) * Math.PI;
      const isMajor = i % 2 === 0;
      const r1 = r - (isMajor ? 18 : 12);
      const r2 = r - 2;
      ctx.beginPath();
      ctx.moveTo(cx + r1 * Math.cos(angle), cy + r1 * Math.sin(angle));
      ctx.lineTo(cx + r2 * Math.cos(angle), cy + r2 * Math.sin(angle));
      ctx.strokeStyle = isMajor ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.3)";
      ctx.lineWidth = isMajor ? 2 : 1;
      ctx.stroke();
    }

    // Needle
    const needleAngle = Math.PI + pct * Math.PI;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + (r - 20) * Math.cos(needleAngle), cy + (r - 20) * Math.sin(needleAngle));
    ctx.strokeStyle = "#ff4400";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.stroke();

    // Center hub
    ctx.beginPath();
    ctx.arc(cx, cy, 8, 0, 2 * Math.PI);
    ctx.fillStyle = "#ff4400";
    ctx.fill();
  }, [speed, maxSpeed]);

  return (
    <canvas
      ref={canvasRef}
      width={180}
      height={100}
      style={{ display: "block" }}
    />
  );
}

function RPMGauge({ rpm }: { rpm: number }) {
  const pct = Math.min(rpm / 8000, 1);
  const isRedline = rpm > 6500;
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="text-xs text-gray-400 font-mono">RPM</div>
      <div className="w-28 h-2 bg-white/10 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-75"
          style={{
            width: `${pct * 100}%`,
            background: isRedline
              ? "linear-gradient(90deg, #ff8800, #ff0000)"
              : "linear-gradient(90deg, #00aaff, #ff8800)",
            boxShadow: isRedline ? "0 0 8px #ff0000" : "0 0 8px #00aaff",
          }}
        />
      </div>
      <div className={`text-xs font-mono font-bold ${isRedline ? "text-red-500" : "text-white/70"}`}>
        {Math.round(rpm / 100) * 100}
      </div>
    </div>
  );
}

function NitroBar({ nitro }: { nitro: number }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="text-xs text-blue-400 font-mono tracking-wider">NITRO</div>
      <div className="w-28 h-3 bg-white/10 rounded-full overflow-hidden border border-white/10">
        <div
          className="h-full rounded-full transition-all duration-75"
          style={{
            width: `${nitro}%`,
            background: "linear-gradient(90deg, #0044ff, #00ccff)",
            boxShadow: nitro > 20 ? "0 0 10px rgba(0, 180, 255, 0.7)" : "none",
          }}
        />
      </div>
      <div className="text-xs font-bold text-blue-300">{Math.round(nitro)}%</div>
    </div>
  );
}

function WantedLevel({ level }: { level: number }) {
  if (level === 0) return null;
  return (
    <div className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-black/60 border border-yellow-500/40">
      <span className="text-yellow-400 text-xs font-bold mr-1">WANTED</span>
      {[1, 2, 3, 4, 5].map(i => (
        <span key={i} className={`text-lg ${i <= level ? "wanted-star" : "wanted-star inactive"}`}>★</span>
      ))}
    </div>
  );
}

function MiniMapHUD({ playerPos }: { playerPos: { x: number; z: number }; playerRot?: number }) {
  return (
    <div className="relative w-28 h-28 rounded-full overflow-hidden border-2 border-white/20 bg-black/70">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-white/20 text-xs">MAP</div>
      </div>
      {/* Road line */}
      <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/20 -translate-x-0.5" />
      {/* Player dot */}
      <div
        className="absolute w-3 h-3 rounded-full bg-orange-500 minimap-dot"
        style={{
          left: `${50 + (playerPos.x / 15) * 35}%`,
          top: "50%",
          transform: "translate(-50%, -50%)",
        }}
      />
    </div>
  );
}

export function HUD({ playerPos }: { playerPos: { x: number; z: number } }) {
  const { playerStats, selectedCar, gameState, setGameState } = useGameStore();
  const [showDriftNotice, setShowDriftNotice] = useState(false);
  const driftTimeRef = useRef(0);

  useEffect(() => {
    if (playerStats.drift > 0.4 && Math.abs(playerStats.speed) > 20) {
      driftTimeRef.current = 2;
      setShowDriftNotice(true);
    }
    const timer = setInterval(() => {
      driftTimeRef.current = Math.max(0, driftTimeRef.current - 0.1);
      if (driftTimeRef.current <= 0) setShowDriftNotice(false);
    }, 100);
    return () => clearInterval(timer);
  }, [playerStats.drift, playerStats.speed]);

  if (gameState !== "playing") return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-10">
      {/* Top bar */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-6">
        <div className="hud-panel px-5 py-2 rounded-xl flex items-center gap-3">
          <span className="text-white/50 text-xs uppercase tracking-widest">Position</span>
          <span className="text-white font-bold text-xl neon-text">{playerStats.position}/{6}</span>
        </div>
        <div className="hud-panel px-5 py-2 rounded-xl flex items-center gap-3">
          <span className="text-white/50 text-xs uppercase tracking-widest">Lap</span>
          <span className="text-white font-bold text-xl neon-text">{playerStats.lap}/{playerStats.totalLaps}</span>
        </div>
      </div>

      {/* Wanted level */}
      <div className="absolute top-4 right-4">
        <WantedLevel level={playerStats.wantedLevel} />
      </div>

      {/* Bottom HUD */}
      <div className="absolute bottom-4 left-0 right-0 flex items-end justify-between px-6">
        {/* Left: MiniMap */}
        <MiniMapHUD playerPos={playerPos} />

        {/* Center: Speed */}
        <div className="flex flex-col items-center">
          <div className="hud-panel px-6 py-4 rounded-2xl flex flex-col items-center gap-2">
            <Speedometer speed={playerStats.speed} maxSpeed={selectedCar.topSpeed} />
            <div className="flex items-end gap-1 mt-1">
              <span className="speed-display text-white font-black text-4xl neon-text leading-none">
                {playerStats.speed}
              </span>
              <span className="text-white/50 text-sm mb-1">km/h</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="bg-orange-500/20 border border-orange-500/50 rounded px-2 py-0.5">
                <span className="text-orange-400 font-bold text-sm">G{playerStats.gear}</span>
              </div>
            </div>
            <RPMGauge rpm={playerStats.rpm} />
            <NitroBar nitro={playerStats.nitro} />
          </div>
        </div>

        {/* Right: Drift score */}
        <div className="flex flex-col items-end gap-3">
          {playerStats.driftScore > 0 && (
            <div className="hud-panel px-4 py-2 rounded-xl text-right">
              <div className="text-white/50 text-xs">DRIFT</div>
              <div className="text-yellow-400 font-bold text-lg neon-text">
                {playerStats.driftScore.toLocaleString()}
              </div>
            </div>
          )}
          <div className="hud-panel px-4 py-2 rounded-xl text-right">
            <div className="text-white/50 text-xs">XP</div>
            <div className="text-green-400 font-bold text-sm">{playerStats.xp.toLocaleString()}</div>
          </div>
        </div>
      </div>

      {/* Drift notice */}
      {showDriftNotice && (
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
          <div className="text-yellow-400 font-black text-3xl tracking-widest uppercase animate-pulse-neon"
            style={{ textShadow: "0 0 20px rgba(255,220,0,0.8), 0 0 40px rgba(255,180,0,0.5)" }}>
            DRIFT!
          </div>
        </div>
      )}

      {/* Controls hint */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 opacity-30 text-white/60 text-xs flex gap-6">
        <span>W/↑ Accelerate</span>
        <span>S/↓ Brake</span>
        <span>A/D Steer</span>
        <span>Space NITRO</span>
        <span>Shift DRIFT</span>
      </div>

      {/* Pause button */}
      <button
        className="absolute top-4 left-4 hud-panel px-3 py-2 rounded-lg text-white/70 text-sm pointer-events-auto hover:text-white transition-colors"
        onClick={() => setGameState("paused")}
      >
        ⏸ Pause
      </button>
    </div>
  );
}

export function PauseMenu() {
  const { setGameState } = useGameStore();
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-lg">
      <div className="flex flex-col items-center gap-6">
        <h2 className="text-white font-black text-5xl tracking-wider neon-text">PAUSED</h2>
        <div className="flex flex-col gap-3 w-56">
          <button
            className="menu-card px-6 py-4 rounded-xl text-white font-bold text-lg tracking-wide"
            onClick={() => setGameState("playing")}
          >
            ▶ Resume
          </button>
          <button
            className="menu-card px-6 py-4 rounded-xl text-white font-bold text-lg tracking-wide"
            onClick={() => setGameState("garage")}
          >
            🚗 Garage
          </button>
          <button
            className="menu-card px-6 py-4 rounded-xl text-white font-bold text-lg tracking-wide"
            onClick={() => setGameState("menu")}
          >
            🏠 Main Menu
          </button>
        </div>
      </div>
    </div>
  );
}
