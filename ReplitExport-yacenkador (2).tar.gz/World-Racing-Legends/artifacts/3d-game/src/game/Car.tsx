import { useRef, useEffect } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import { useGameStore } from "../store/gameStore";

enum Controls {
  forward = "forward",
  back = "back",
  left = "left",
  right = "right",
  nitro = "nitro",
  brake = "brake",
}

interface CarProps {
  onPositionChange?: (pos: THREE.Vector3, rotation: number) => void;
}

const SMOKE_POSITIONS = [
  [-0.8, 0.1, -2.1],
  [0.8, 0.1, -2.1],
] as [number, number, number][];

function CarBody({ color, brand }: { color: string; brand: string }) {
  const isBugatti = brand === "Bugatti";
  const isLambo = brand === "Lamborghini";

  return (
    <group>
      {/* Chassis */}
      <mesh position={[0, 0.35, 0]} castShadow>
        <boxGeometry args={[1.8, 0.25, 4.2]} />
        <meshStandardMaterial color="#111" metalness={0.9} roughness={0.1} />
      </mesh>

      {/* Main body */}
      <mesh position={[0, 0.65, 0.1]} castShadow>
        <boxGeometry args={[1.75, 0.55, 3.8]} />
        <meshStandardMaterial color={color} metalness={0.8} roughness={0.15} envMapIntensity={1.5} />
      </mesh>

      {/* Cabin */}
      <mesh position={[0, 1.02, 0.2]} castShadow>
        <boxGeometry args={[1.5, 0.55, 2.0]} />
        <meshStandardMaterial color={color} metalness={0.7} roughness={0.2} />
      </mesh>

      {/* Roof */}
      <mesh position={[0, 1.35, 0.2]}>
        <boxGeometry args={[1.45, 0.1, 1.9]} />
        <meshStandardMaterial color={color} metalness={0.8} roughness={0.15} />
      </mesh>

      {/* Front windshield */}
      <mesh position={[0, 1.0, 1.18]} rotation={[0.4, 0, 0]}>
        <boxGeometry args={[1.38, 0.65, 0.05]} />
        <meshStandardMaterial color="#112233" transparent opacity={0.7} metalness={0.1} roughness={0.0} />
      </mesh>

      {/* Rear windshield */}
      <mesh position={[0, 1.0, -0.78]} rotation={[-0.4, 0, 0]}>
        <boxGeometry args={[1.38, 0.6, 0.05]} />
        <meshStandardMaterial color="#112233" transparent opacity={0.6} />
      </mesh>

      {/* Hood slope */}
      <mesh position={[0, 0.72, 1.7]} rotation={[-0.18, 0, 0]}>
        <boxGeometry args={[1.7, 0.08, 0.9]} />
        <meshStandardMaterial color={color} metalness={0.8} roughness={0.15} />
      </mesh>

      {/* Spoiler */}
      {(isBugatti || isLambo) && (
        <>
          <mesh position={[0, 1.1, -2.0]}>
            <boxGeometry args={[1.6, 0.08, 0.5]} />
            <meshStandardMaterial color={color} metalness={0.9} roughness={0.1} />
          </mesh>
          <mesh position={[-0.75, 0.85, -2.0]}>
            <boxGeometry args={[0.06, 0.5, 0.1]} />
            <meshStandardMaterial color="#222" metalness={0.9} roughness={0.1} />
          </mesh>
          <mesh position={[0.75, 0.85, -2.0]}>
            <boxGeometry args={[0.06, 0.5, 0.1]} />
            <meshStandardMaterial color="#222" metalness={0.9} roughness={0.1} />
          </mesh>
        </>
      )}

      {/* Front bumper */}
      <mesh position={[0, 0.42, 2.12]}>
        <boxGeometry args={[1.78, 0.28, 0.14]} />
        <meshStandardMaterial color="#222" metalness={0.7} roughness={0.3} />
      </mesh>

      {/* Rear bumper */}
      <mesh position={[0, 0.42, -2.12]}>
        <boxGeometry args={[1.78, 0.28, 0.14]} />
        <meshStandardMaterial color="#222" metalness={0.7} roughness={0.3} />
      </mesh>

      {/* Headlights */}
      <mesh position={[0.65, 0.62, 2.16]}>
        <boxGeometry args={[0.4, 0.18, 0.06]} />
        <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={2} />
      </mesh>
      <mesh position={[-0.65, 0.62, 2.16]}>
        <boxGeometry args={[0.4, 0.18, 0.06]} />
        <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={2} />
      </mesh>

      {/* Tail lights */}
      <mesh position={[0.65, 0.62, -2.16]}>
        <boxGeometry args={[0.4, 0.18, 0.06]} />
        <meshStandardMaterial color="#ff2200" emissive="#ff2200" emissiveIntensity={2} />
      </mesh>
      <mesh position={[-0.65, 0.62, -2.16]}>
        <boxGeometry args={[0.4, 0.18, 0.06]} />
        <meshStandardMaterial color="#ff2200" emissive="#ff2200" emissiveIntensity={2} />
      </mesh>

      {/* Exhaust pipes */}
      <mesh position={[0.5, 0.28, -2.12]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.07, 0.07, 0.2, 8]} />
        <meshStandardMaterial color="#333" metalness={0.9} roughness={0.1} />
      </mesh>
      <mesh position={[-0.5, 0.28, -2.12]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.07, 0.07, 0.2, 8]} />
        <meshStandardMaterial color="#333" metalness={0.9} roughness={0.1} />
      </mesh>

      {/* Wheels */}
      {[
        [0.97, 0.28, 1.4],
        [-0.97, 0.28, 1.4],
        [0.97, 0.28, -1.4],
        [-0.97, 0.28, -1.4],
      ].map((pos, i) => (
        <group key={i} position={pos as [number, number, number]}>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.38, 0.38, 0.25, 16]} />
            <meshStandardMaterial color="#111" roughness={0.9} />
          </mesh>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.28, 0.28, 0.28, 12]} />
            <meshStandardMaterial color="#888" metalness={0.8} roughness={0.2} />
          </mesh>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.1, 0.1, 0.32, 8]} />
            <meshStandardMaterial color="#555" metalness={0.9} roughness={0.1} />
          </mesh>
        </group>
      ))}

      {/* Neon underglow */}
      <pointLight position={[0, -0.1, 0]} intensity={0.5} distance={4} color="#00aaff" />
    </group>
  );
}

export function PlayerCar({ onPositionChange }: CarProps) {
  const groupRef = useRef<THREE.Group>(null);
  const velocityRef = useRef(0);
  const rotationRef = useRef(0);
  const driftRef = useRef(0);
  const nitroActive = useRef(false);
  const smokeRefs = useRef<THREE.Mesh[]>([]);

  const [, getControls] = useKeyboardControls<Controls>();
  const { selectedCar, playerStats, updateStats, gameState } = useGameStore();

  useEffect(() => {
    if (groupRef.current) {
      groupRef.current.position.set(0, 0, 0);
    }
    velocityRef.current = 0;
    rotationRef.current = 0;
  }, []);

  useFrame((_, delta) => {
    if (!groupRef.current || gameState !== "playing") return;
    const controls = getControls();

    const dt = Math.min(delta, 0.05);
    const maxSpeed = (selectedCar.topSpeed / 3.6) * 0.08;
    const accel = selectedCar.acceleration * 0.0015;
    const handling = selectedCar.handling * 0.0008;
    const nitroBonusSpeed = selectedCar.turbo * 0.012;

    const isNitroActive = controls.nitro && playerStats.nitro > 0;
    nitroActive.current = isNitroActive;

    let targetVelocity = velocityRef.current;

    if (controls.forward) {
      const speed = isNitroActive ? accel * 2.5 : accel;
      targetVelocity = Math.min(targetVelocity + speed, isNitroActive ? maxSpeed + nitroBonusSpeed : maxSpeed);
    } else if (controls.back) {
      targetVelocity = Math.max(targetVelocity - accel * 1.2, -maxSpeed * 0.4);
    } else {
      targetVelocity *= 0.97;
    }

    if (controls.brake) {
      targetVelocity *= 0.93;
      driftRef.current = Math.min(driftRef.current + 0.05, 1);
    } else {
      driftRef.current *= 0.9;
    }

    velocityRef.current = targetVelocity;

    const speedFactor = Math.abs(velocityRef.current) / maxSpeed;
    const steerAmount = handling * speedFactor * (1 + driftRef.current * 0.5);

    if (controls.left) rotationRef.current += steerAmount;
    if (controls.right) rotationRef.current -= steerAmount;

    groupRef.current.rotation.y = rotationRef.current;

    const moveX = Math.sin(rotationRef.current) * velocityRef.current;
    const moveZ = Math.cos(rotationRef.current) * velocityRef.current;

    groupRef.current.position.x += moveX;
    groupRef.current.position.z += moveZ;

    // Keep on road
    groupRef.current.position.x = Math.max(-9.5, Math.min(9.5, groupRef.current.position.x));
    groupRef.current.position.y = 0;

    // Visual drift tilt
    const tiltZ = controls.left ? 0.05 : controls.right ? -0.05 : 0;
    groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, tiltZ * speedFactor, 0.1);

    // Update stats
    const speedKmh = Math.abs(velocityRef.current) * (3.6 / 0.08) * (selectedCar.topSpeed / 340);
    const gear = Math.min(6, Math.max(1, Math.ceil(speedKmh / 50)));
    const rpm = 800 + (speedKmh / selectedCar.topSpeed) * 7200;
    const isDrifting = driftRef.current > 0.3 && speedFactor > 0.3;
    const newDriftScore = isDrifting ? playerStats.driftScore + 10 : playerStats.driftScore;

    updateStats({
      speed: Math.round(speedKmh),
      rpm: Math.round(rpm),
      gear,
      nitro: isNitroActive
        ? Math.max(0, playerStats.nitro - 30 * dt)
        : Math.min(100, playerStats.nitro + 10 * dt),
      drift: driftRef.current,
      driftScore: newDriftScore,
    });

    onPositionChange?.(groupRef.current.position, rotationRef.current);
  });

  return (
    <group ref={groupRef} position={[0, 0, 5]}>
      <CarBody color={selectedCar.color} brand={selectedCar.brand} />

      {/* Headlight beams */}
      <spotLight position={[0.6, 0.6, 2.5]} target-position={[0.6, -1, 15]} intensity={3} angle={0.3} penumbra={0.5} color="#ffe8cc" distance={40} />
      <spotLight position={[-0.6, 0.6, 2.5]} target-position={[-0.6, -1, 15]} intensity={3} angle={0.3} penumbra={0.5} color="#ffe8cc" distance={40} />

      {/* Nitro exhaust flame */}
      {nitroActive.current && (
        <>
          <pointLight position={[0.5, 0.28, -2.5]} intensity={5} distance={5} color="#ff6600" />
          <pointLight position={[-0.5, 0.28, -2.5]} intensity={5} distance={5} color="#ff6600" />
          <mesh position={[0.5, 0.28, -2.5]}>
            <coneGeometry args={[0.12, 0.6, 6]} rotation={[Math.PI / 2, 0, 0]} />
            <meshStandardMaterial color="#ff4400" emissive="#ff6600" emissiveIntensity={4} transparent opacity={0.8} />
          </mesh>
        </>
      )}
    </group>
  );
}

interface AICar {
  id: number;
  position: THREE.Vector3;
  rotation: number;
  velocity: number;
  color: string;
  wantedLevel: number;
}

interface AICarMeshProps {
  car: AICar;
  isPolice?: boolean;
}

function AICarMesh({ car, isPolice }: AICarMeshProps) {
  const policeColor = isPolice ? "#111122" : car.color;
  return (
    <group position={car.position} rotation={[0, car.rotation, 0]}>
      <mesh position={[0, 0.55, 0]} castShadow>
        <boxGeometry args={[1.7, 0.6, 3.8]} />
        <meshStandardMaterial color={policeColor} metalness={0.7} roughness={0.2} />
      </mesh>
      <mesh position={[0, 0.95, 0.1]} castShadow>
        <boxGeometry args={[1.45, 0.5, 1.9]} />
        <meshStandardMaterial color={policeColor} metalness={0.6} roughness={0.3} />
      </mesh>
      {isPolice && (
        <mesh position={[0, 1.3, 0]}>
          <boxGeometry args={[0.8, 0.2, 0.4]} />
          <meshStandardMaterial color="#cc0000" emissive="#ff0000" emissiveIntensity={3} />
        </mesh>
      )}
      {[
        [0.87, 0.28, 1.2],
        [-0.87, 0.28, 1.2],
        [0.87, 0.28, -1.2],
        [-0.87, 0.28, -1.2],
      ].map((p, i) => (
        <mesh key={i} position={p as [number, number, number]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.32, 0.32, 0.22, 12]} />
          <meshStandardMaterial color="#111" roughness={0.9} />
        </mesh>
      ))}
      {isPolice && (
        <pointLight position={[0, 1.5, 0]} intensity={3} distance={15} color="#0044ff" />
      )}
    </group>
  );
}

const AI_CARS_INIT: AICar[] = [
  { id: 1, position: new THREE.Vector3(3, 0, -15), rotation: 0, velocity: 0.08, color: "#4488ff", wantedLevel: 0 },
  { id: 2, position: new THREE.Vector3(-3, 0, -25), rotation: 0, velocity: 0.07, color: "#44ff88", wantedLevel: 0 },
  { id: 3, position: new THREE.Vector3(3, 0, -40), rotation: 0, velocity: 0.09, color: "#ff8844", wantedLevel: 0 },
  { id: 4, position: new THREE.Vector3(-3, 0, -55), rotation: 0, velocity: 0.075, color: "#ff44ff", wantedLevel: 0 },
];

export function AITrafficCars({ playerPos }: { playerPos: THREE.Vector3 }) {
  const carsRef = useRef<AICar[]>(AI_CARS_INIT.map(c => ({ ...c, position: c.position.clone() })));
  const { playerStats } = useGameStore();

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.05);
    carsRef.current.forEach(car => {
      car.position.z += car.velocity;
      if (car.position.z > playerPos.z + 80) {
        car.position.z = playerPos.z - 120;
        car.position.x = (Math.random() > 0.5 ? 1 : -1) * (2 + Math.random() * 5);
      }
    });
  });

  return (
    <group>
      {carsRef.current.map(car => (
        <AICarMesh key={car.id} car={car} />
      ))}
      {playerStats.wantedLevel >= 2 && (
        <AICarMesh
          car={{ id: 99, position: new THREE.Vector3(playerPos.x + 5, 0, playerPos.z - 20), rotation: 0, velocity: 0, color: "#000", wantedLevel: 5 }}
          isPolice
        />
      )}
    </group>
  );
}
