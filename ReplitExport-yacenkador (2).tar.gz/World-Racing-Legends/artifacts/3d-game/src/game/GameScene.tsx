import { Suspense, useRef, useState, useCallback } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { KeyboardControls, PerformanceMonitor } from "@react-three/drei";
import * as THREE from "three";
import { Environment } from "./Environment";
import { PlayerCar, AITrafficCars } from "./Car";
import { HUD, PauseMenu } from "./HUD";
import { useGameStore } from "../store/gameStore";

enum Controls {
  forward = "forward",
  back = "back",
  left = "left",
  right = "right",
  nitro = "nitro",
  brake = "brake",
}

const keyMap = [
  { name: Controls.forward, keys: ["ArrowUp", "KeyW"] },
  { name: Controls.back, keys: ["ArrowDown", "KeyS"] },
  { name: Controls.left, keys: ["ArrowLeft", "KeyA"] },
  { name: Controls.right, keys: ["ArrowRight", "KeyD"] },
  { name: Controls.nitro, keys: ["Space"] },
  { name: Controls.brake, keys: ["ShiftLeft", "ShiftRight"] },
];

interface CarTarget {
  position: THREE.Vector3;
  rotation: number;
}

function CameraController({ targetRef }: { targetRef: React.MutableRefObject<CarTarget> }) {
  const camPosRef = useRef(new THREE.Vector3(0, 8, 20));
  const camLookRef = useRef(new THREE.Vector3(0, 1, 0));

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const { position, rotation } = targetRef.current;

    const offsetDist = 12;
    const offsetHeight = 5;

    const offsetX = Math.sin(rotation) * -offsetDist;
    const offsetZ = Math.cos(rotation) * -offsetDist;

    const targetCamPos = new THREE.Vector3(
      position.x + offsetX,
      position.y + offsetHeight,
      position.z + offsetZ
    );

    camPosRef.current.lerp(targetCamPos, Math.min(dt * 6, 1));

    const lookTarget = new THREE.Vector3(position.x, position.y + 1, position.z);
    camLookRef.current.lerp(lookTarget, Math.min(dt * 8, 1));

    state.camera.position.copy(camPosRef.current);
    state.camera.lookAt(camLookRef.current);
  });

  return null;
}

function GameWorld({
  targetRef,
  onCarMove,
}: {
  targetRef: React.MutableRefObject<CarTarget>;
  onCarMove: (pos: THREE.Vector3, rot: number) => void;
}) {
  const playerPosRef = useRef(new THREE.Vector3(0, 0, 0));

  const handleCarMove = useCallback(
    (pos: THREE.Vector3, rot: number) => {
      playerPosRef.current.copy(pos);
      targetRef.current.position.copy(pos);
      targetRef.current.rotation = rot;
      onCarMove(pos, rot);
    },
    [onCarMove, targetRef]
  );

  return (
    <>
      <Environment />
      <PlayerCar onPositionChange={handleCarMove} />
      <AITrafficCars playerPos={playerPosRef.current} />
      <CameraController targetRef={targetRef} />
    </>
  );
}

export function GameScene() {
  const { gameState } = useGameStore();
  const [playerPos, setPlayerPos] = useState({ x: 0, z: 0 });

  const targetRef = useRef<CarTarget>({
    position: new THREE.Vector3(0, 0, 0),
    rotation: 0,
  });

  const handleCarMove = useCallback((pos: THREE.Vector3, _rot: number) => {
    setPlayerPos({ x: pos.x, z: pos.z });
  }, []);

  return (
    <div className="fixed inset-0 w-full h-full">
      <KeyboardControls map={keyMap}>
        <Canvas
          shadows
          gl={{
            antialias: true,
            toneMapping: THREE.ACESFilmicToneMapping,
            toneMappingExposure: 1.2,
            powerPreference: "high-performance",
          }}
          camera={{ position: [0, 8, 20], fov: 65, near: 0.1, far: 600 }}
          onCreated={({ gl }) => {
            gl.shadowMap.enabled = true;
            gl.shadowMap.type = THREE.PCFSoftShadowMap;
          }}
        >
          <PerformanceMonitor onIncline={() => {}} onDecline={() => {}} />
          <Suspense fallback={null}>
            <GameWorld targetRef={targetRef} onCarMove={handleCarMove} />
          </Suspense>
        </Canvas>
      </KeyboardControls>

      <HUD playerPos={playerPos} />
      {gameState === "paused" && <PauseMenu />}
    </div>
  );
}
