import { create } from "zustand";

export type GameState = "menu" | "loading" | "playing" | "paused" | "garage" | "gameover";
export type WeatherType = "clear" | "rain" | "storm" | "snow";
export type TimeOfDay = "day" | "night" | "sunset";

export interface CarConfig {
  id: string;
  name: string;
  brand: string;
  color: string;
  topSpeed: number;
  acceleration: number;
  handling: number;
  turbo: number;
  price: number;
  unlocked: boolean;
  description: string;
}

export interface PlayerStats {
  speed: number;
  rpm: number;
  gear: number;
  nitro: number;
  fuel: number;
  position: number;
  lap: number;
  totalLaps: number;
  raceTime: number;
  bestLap: number;
  xp: number;
  coins: number;
  drift: number;
  driftScore: number;
  wantedLevel: number;
  policeDistance: number;
}

interface GameStore {
  gameState: GameState;
  weather: WeatherType;
  timeOfDay: TimeOfDay;
  selectedCar: CarConfig;
  playerStats: PlayerStats;
  cars: CarConfig[];
  score: number;
  highScore: number;
  totalCoins: number;
  showControls: boolean;
  setGameState: (state: GameState) => void;
  setWeather: (weather: WeatherType) => void;
  setTimeOfDay: (time: TimeOfDay) => void;
  setSelectedCar: (car: CarConfig) => void;
  updateStats: (stats: Partial<PlayerStats>) => void;
  addScore: (pts: number) => void;
  addCoins: (coins: number) => void;
  resetStats: () => void;
  setShowControls: (show: boolean) => void;
}

export const CARS: CarConfig[] = [
  { id: "ferrari", name: "SF-90 Stradale", brand: "Ferrari", color: "#CC0000", topSpeed: 340, acceleration: 9.5, handling: 9.0, turbo: 8.5, price: 0, unlocked: true, description: "Italian excellence – pure racing DNA" },
  { id: "lamborghini", name: "Huracán STO", brand: "Lamborghini", color: "#FF6B00", topSpeed: 320, acceleration: 9.8, handling: 8.8, turbo: 9.0, price: 0, unlocked: true, description: "Born on the track, built for the street" },
  { id: "bugatti", name: "Chiron Super Sport", brand: "Bugatti", color: "#1E3A8A", topSpeed: 440, acceleration: 10, handling: 8.0, turbo: 10, price: 50000, unlocked: false, description: "The pinnacle of automotive engineering" },
  { id: "mclaren", name: "720S Spider", brand: "McLaren", color: "#F97316", topSpeed: 341, acceleration: 9.6, handling: 9.5, turbo: 8.8, price: 30000, unlocked: false, description: "Track champion unleashed on the road" },
  { id: "porsche", name: "911 GT3 RS", brand: "Porsche", color: "#FFFFFF", topSpeed: 296, acceleration: 8.5, handling: 10, turbo: 7.5, price: 20000, unlocked: false, description: "Precision engineering for the apex hunter" },
  { id: "bmw", name: "M8 Competition", brand: "BMW", color: "#003366", topSpeed: 305, acceleration: 8.8, handling: 8.7, turbo: 8.0, price: 15000, unlocked: false, description: "Ultimate driving machine – evolved" },
  { id: "nissan", name: "GT-R NISMO", brand: "Nissan", color: "#C0C0C0", topSpeed: 315, acceleration: 9.0, handling: 9.2, turbo: 9.5, price: 25000, unlocked: false, description: "Godzilla reborn – AWD dominance" },
  { id: "dodge", name: "Challenger SRT Demon", brand: "Dodge", color: "#1A1A1A", topSpeed: 330, acceleration: 9.9, handling: 7.5, turbo: 8.0, price: 18000, unlocked: false, description: "American muscle – raw and unfiltered" },
  { id: "police", name: "Police Interceptor", brand: "Ford", color: "#1E1E1E", topSpeed: 280, acceleration: 8.0, handling: 8.5, turbo: 7.0, price: 35000, unlocked: false, description: "Law enforcement's finest pursuit vehicle" },
  { id: "tesla", name: "Model S Plaid", brand: "Tesla", color: "#E5E7EB", topSpeed: 320, acceleration: 10, handling: 8.5, turbo: 10, price: 22000, unlocked: false, description: "The future of speed is electric" },
];

const defaultStats: PlayerStats = {
  speed: 0, rpm: 0, gear: 1, nitro: 100, fuel: 100,
  position: 1, lap: 1, totalLaps: 3, raceTime: 0, bestLap: 0,
  xp: 0, coins: 0, drift: 0, driftScore: 0, wantedLevel: 0, policeDistance: 500,
};

export const useGameStore = create<GameStore>((set) => ({
  gameState: "menu",
  weather: "clear",
  timeOfDay: "day",
  selectedCar: CARS[0],
  playerStats: defaultStats,
  cars: CARS,
  score: 0,
  highScore: 0,
  totalCoins: 99999,
  showControls: false,
  setGameState: (state) => set({ gameState: state }),
  setWeather: (weather) => set({ weather }),
  setTimeOfDay: (timeOfDay) => set({ timeOfDay }),
  setSelectedCar: (selectedCar) => set({ selectedCar }),
  updateStats: (stats) => set((s) => ({ playerStats: { ...s.playerStats, ...stats } })),
  addScore: (pts) => set((s) => ({ score: s.score + pts, highScore: Math.max(s.highScore, s.score + pts) })),
  addCoins: (coins) => set((s) => ({ totalCoins: s.totalCoins + coins })),
  resetStats: () => set({ playerStats: defaultStats, score: 0 }),
  setShowControls: (showControls) => set({ showControls }),
}));
