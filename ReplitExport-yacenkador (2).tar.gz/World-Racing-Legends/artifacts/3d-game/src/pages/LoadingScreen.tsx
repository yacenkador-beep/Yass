import { useEffect, useState } from "react";
import { useGameStore } from "../store/gameStore";

const TIPS = [
  "Hold SPACE to activate NITRO for a massive speed boost!",
  "Hold SHIFT while turning for epic drift combos.",
  "Build up your Wanted Level to unlock secret police chase missions.",
  "Collect XP to unlock new cars and upgrades.",
  "Use the Garage to tune your car for different race types.",
  "Night races give 2x XP bonus — choose your time wisely.",
  "Rain makes roads slippery — adjust your handling accordingly.",
  "Drift scoring multiplies for consecutive combos!",
];

export function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  const [tip] = useState(() => TIPS[Math.floor(Math.random() * TIPS.length)]);
  const { selectedCar } = useGameStore();

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(interval); return 100; }
        return p + Math.random() * 8 + 3;
      });
    }, 80);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center overflow-hidden">
      {/* Animated background */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          background: `radial-gradient(ellipse at 30% 50%, ${selectedCar.color}44 0%, transparent 60%),
                       radial-gradient(ellipse at 70% 50%, #0044ff22 0%, transparent 60%)`,
        }}
      />

      {/* Speed lines */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }, (_, i) => (
          <div
            key={i}
            className="absolute h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"
            style={{
              top: `${5 + i * 5}%`,
              left: "-100%",
              width: "200%",
              animation: `slideRight ${0.5 + Math.random() * 1}s linear infinite`,
              animationDelay: `${Math.random() * 2}s`,
              opacity: 0.3 + Math.random() * 0.4,
            }}
          />
        ))}
      </div>

      <style>{`
        @keyframes slideRight {
          from { transform: translateX(-50%); }
          to { transform: translateX(50%); }
        }
      `}</style>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center gap-8 w-full max-w-xl px-8">
        {/* Title */}
        <div className="text-center">
          <div className="text-orange-500 text-xs font-bold tracking-[0.4em] uppercase mb-2">World Racing</div>
          <h1 className="text-white font-black text-5xl tracking-tight leading-none">
            HYPER <span className="text-orange-500 neon-text">DRIFT</span>
          </h1>
        </div>

        {/* Car showcase */}
        <div
          className="w-40 h-24 rounded-xl flex items-center justify-center text-6xl"
          style={{
            background: `radial-gradient(ellipse, ${selectedCar.color}30, transparent)`,
            border: `1px solid ${selectedCar.color}40`,
          }}
        >
          🏎
        </div>

        {/* Car name */}
        <div className="text-center">
          <div className="text-white/40 text-xs uppercase tracking-widest">{selectedCar.brand}</div>
          <div className="text-white font-bold text-xl">{selectedCar.name}</div>
        </div>

        {/* Progress bar */}
        <div className="w-full">
          <div className="flex justify-between text-xs text-white/40 mb-2">
            <span>LOADING WORLD</span>
            <span>{Math.min(100, Math.round(progress))}%</span>
          </div>
          <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-100"
              style={{
                width: `${Math.min(100, progress)}%`,
                background: `linear-gradient(90deg, #ff6600, ${selectedCar.color})`,
                boxShadow: `0 0 10px ${selectedCar.color}`,
              }}
            />
          </div>
        </div>

        {/* Loading items */}
        <div className="flex gap-4 text-xs text-white/30">
          {["World Map", "Physics", "AI System", "Cars", "Audio"].map((item, i) => (
            <div
              key={item}
              className={`flex items-center gap-1 transition-all duration-500 ${
                progress > i * 20 ? "text-white/60" : "text-white/20"
              }`}
            >
              <div className={`w-1.5 h-1.5 rounded-full ${progress > i * 20 ? "bg-orange-500" : "bg-white/20"}`} />
              {item}
            </div>
          ))}
        </div>

        {/* Tip */}
        <div className="hud-panel px-6 py-4 rounded-xl w-full">
          <div className="text-orange-500 text-xs font-bold mb-1">💡 TIP</div>
          <p className="text-white/70 text-sm leading-relaxed">{tip}</p>
        </div>
      </div>
    </div>
  );
}
