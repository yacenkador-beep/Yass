import { useState } from "react";
import { useGameStore, CARS, CarConfig } from "../store/gameStore";

function StatBar({ label, value, max = 10, color }: { label: string; value: number; max?: number; color: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-white/40 text-xs w-16 text-right">{label}</span>
      <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${(value / max) * 100}%`, background: color }}
        />
      </div>
      <span className="text-white/60 text-xs w-6 text-right">{value.toFixed(1)}</span>
    </div>
  );
}

export function GaragePage() {
  const { selectedCar, setSelectedCar, setGameState, totalCoins, cars } = useGameStore();
  const [previewCar, setPreviewCar] = useState<CarConfig>(selectedCar);
  const [tab, setTab] = useState<"cars" | "upgrade">("cars");

  const handleSelectCar = (car: CarConfig) => {
    if (car.unlocked) {
      setSelectedCar(car);
      setPreviewCar(car);
    }
  };

  return (
    <div className="fixed inset-0 menu-bg overflow-hidden flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-8 py-4 border-b border-white/5">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setGameState("menu")}
            className="text-white/50 hover:text-white transition-colors text-sm flex items-center gap-2"
          >
            ← Back
          </button>
          <h1 className="text-white font-black text-2xl tracking-wider">GARAGE</h1>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-yellow-400 font-bold">🪙 {totalCoins.toLocaleString()}</span>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left: Car list */}
        <div className="w-64 border-r border-white/5 overflow-y-auto p-4 flex flex-col gap-2">
          {/* Tabs */}
          <div className="flex gap-2 mb-2">
            <button
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${tab === "cars" ? "bg-orange-500/20 text-orange-400 border border-orange-500/40" : "text-white/40 hover:text-white/70"}`}
              onClick={() => setTab("cars")}
            >
              Cars
            </button>
            <button
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${tab === "upgrade" ? "bg-orange-500/20 text-orange-400 border border-orange-500/40" : "text-white/40 hover:text-white/70"}`}
              onClick={() => setTab("upgrade")}
            >
              Upgrades
            </button>
          </div>

          {CARS.map((car) => (
            <button
              key={car.id}
              className={`car-card p-3 rounded-xl text-left transition-all ${previewCar.id === car.id ? "selected" : ""} ${!car.unlocked ? "opacity-50" : ""}`}
              onClick={() => setPreviewCar(car)}
            >
              <div className="flex items-center gap-2">
                <div
                  className="w-8 h-5 rounded"
                  style={{ background: car.color, boxShadow: `0 0 8px ${car.color}60` }}
                />
                <div>
                  <div className="text-white text-xs font-bold">{car.brand}</div>
                  <div className="text-white/40 text-xs">{car.name}</div>
                </div>
                {!car.unlocked && <span className="ml-auto text-xs">🔒</span>}
              </div>
            </button>
          ))}
        </div>

        {/* Center: Car preview */}
        <div className="flex-1 flex flex-col items-center justify-center p-8">
          {/* 3D-style car display */}
          <div
            className="w-72 h-48 rounded-2xl flex items-center justify-center mb-6 relative overflow-hidden"
            style={{
              background: `radial-gradient(ellipse at 50% 60%, ${previewCar.color}30 0%, transparent 70%)`,
              border: `1px solid ${previewCar.color}30`,
              boxShadow: `0 0 60px ${previewCar.color}20`,
            }}
          >
            {/* Grid floor */}
            <div className="absolute inset-0 opacity-10"
              style={{
                backgroundImage: `linear-gradient(${previewCar.color} 1px, transparent 1px), linear-gradient(90deg, ${previewCar.color} 1px, transparent 1px)`,
                backgroundSize: "20px 20px",
                transform: "perspective(200px) rotateX(60deg) translateY(50px)",
              }}
            />

            {/* Car silhouette */}
            <div className="text-8xl drift-anim z-10">🏎</div>

            {/* Glow */}
            <div
              className="absolute bottom-0 left-1/2 -translate-x-1/2 w-40 h-8 rounded-full blur-xl opacity-40"
              style={{ background: previewCar.color }}
            />
          </div>

          {/* Car info */}
          <div className="text-center mb-6">
            <div className="text-white/40 text-xs tracking-widest uppercase mb-1">{previewCar.brand}</div>
            <h2 className="text-white font-black text-3xl">{previewCar.name}</h2>
            <p className="text-white/40 text-sm mt-1 italic">{previewCar.description}</p>

            <div className="flex items-center justify-center gap-6 mt-4">
              <div className="text-center">
                <div className="text-orange-400 font-black text-2xl">{previewCar.topSpeed}</div>
                <div className="text-white/30 text-xs">km/h</div>
              </div>
              <div className="w-px h-10 bg-white/10" />
              <div className="text-center">
                <div className="text-blue-400 font-black text-2xl">{previewCar.acceleration.toFixed(1)}</div>
                <div className="text-white/30 text-xs">0-100</div>
              </div>
              <div className="w-px h-10 bg-white/10" />
              <div className="text-center">
                <div className="text-green-400 font-black text-2xl">{previewCar.handling.toFixed(1)}</div>
                <div className="text-white/30 text-xs">handling</div>
              </div>
            </div>
          </div>

          {/* Color swatches */}
          <div className="flex gap-3 mb-6">
            {["#CC0000", "#FF6B00", "#1E3A8A", "#FFFFFF", "#111111", "#44CC88", "#AA44FF"].map((c) => (
              <button
                key={c}
                className="w-7 h-7 rounded-full border-2 transition-all hover:scale-110"
                style={{
                  background: c,
                  borderColor: previewCar.color === c ? "white" : "transparent",
                  boxShadow: `0 0 8px ${c}80`,
                }}
              />
            ))}
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            {previewCar.unlocked ? (
              <>
                <button
                  className="px-8 py-3 rounded-xl font-black text-white transition-all"
                  style={{
                    background: selectedCar.id === previewCar.id
                      ? "rgba(255,150,0,0.2)"
                      : "linear-gradient(135deg, #ff6600, #ff2200)",
                    border: selectedCar.id === previewCar.id ? "1px solid rgba(255,150,0,0.5)" : "none",
                    boxShadow: selectedCar.id === previewCar.id ? "none" : "0 4px 20px rgba(255,80,0,0.5)",
                  }}
                  onClick={() => handleSelectCar(previewCar)}
                >
                  {selectedCar.id === previewCar.id ? "✓ Selected" : "Select Car"}
                </button>
                <button
                  className="px-6 py-3 rounded-xl font-bold text-white/70 border border-white/20 hover:border-orange-500/50 hover:text-white transition-all"
                  onClick={() => {
                    setSelectedCar(previewCar);
                    setGameState("loading");
                    setTimeout(() => setGameState("playing"), 2000);
                  }}
                >
                  🏁 Race Now
                </button>
              </>
            ) : (
              <button
                className="px-8 py-3 rounded-xl font-black text-white transition-all"
                style={{
                  background: totalCoins >= previewCar.price
                    ? "linear-gradient(135deg, #FFD700, #FF8C00)"
                    : "rgba(100,100,100,0.3)",
                  boxShadow: totalCoins >= previewCar.price ? "0 4px 20px rgba(255,200,0,0.4)" : "none",
                }}
              >
                🪙 {previewCar.price.toLocaleString()}
              </button>
            )}
          </div>
        </div>

        {/* Right: Stats & upgrades */}
        <div className="w-64 border-l border-white/5 p-6 flex flex-col gap-4">
          <div>
            <div className="text-orange-500 text-xs font-bold tracking-widest mb-4">PERFORMANCE</div>
            <div className="flex flex-col gap-3">
              <StatBar label="Top Speed" value={previewCar.topSpeed / 44} color="#ff4400" />
              <StatBar label="Accel" value={previewCar.acceleration} color="#ff8800" />
              <StatBar label="Handling" value={previewCar.handling} color="#00aaff" />
              <StatBar label="Turbo" value={previewCar.turbo} color="#aa44ff" />
            </div>
          </div>

          <div className="h-px bg-white/5" />

          <div>
            <div className="text-orange-500 text-xs font-bold tracking-widest mb-4">UPGRADES</div>
            {[
              { name: "Engine Tune", cost: 5000, icon: "⚙️", level: 0 },
              { name: "Turbo Boost", cost: 8000, icon: "💨", level: 0 },
              { name: "Suspension", cost: 4000, icon: "🔧", level: 0 },
              { name: "Tires", cost: 3000, icon: "⭕", level: 1 },
              { name: "Nitro System", cost: 6000, icon: "🔵", level: 0 },
              { name: "Exhaust", cost: 2000, icon: "🔥", level: 2 },
            ].map((upg) => (
              <div key={upg.name} className="flex items-center gap-2 py-2 border-b border-white/5">
                <span className="text-lg">{upg.icon}</span>
                <div className="flex-1">
                  <div className="text-white text-xs font-bold">{upg.name}</div>
                  <div className="flex gap-0.5 mt-0.5">
                    {[0, 1, 2].map(i => (
                      <div key={i} className={`w-4 h-1 rounded-full ${i < upg.level ? "bg-orange-500" : "bg-white/10"}`} />
                    ))}
                  </div>
                </div>
                <span className="text-yellow-400/60 text-xs">🪙 {upg.cost.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
