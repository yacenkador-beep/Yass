import { useState, useEffect } from "react";
import { useGameStore } from "../store/gameStore";

const MENU_ITEMS = [
  { id: "play", label: "Quick Race", icon: "🏁", desc: "Jump into the action" },
  { id: "garage", label: "Garage", icon: "🚗", desc: "Manage & upgrade your fleet" },
  { id: "career", label: "Career Mode", icon: "🏆", desc: "Rise through the ranks" },
  { id: "drift", label: "Drift Mode", icon: "💨", desc: "Score massive drift combos" },
  { id: "police", label: "Police Chase", icon: "🚔", desc: "Outrun the law" },
  { id: "settings", label: "Settings", icon: "⚙️", desc: "Graphics & controls" },
];

function AnimatedCar() {
  return (
    <div className="relative w-full h-48 flex items-center justify-center overflow-hidden">
      {/* Decorative car silhouette */}
      <div className="relative drift-anim">
        <svg viewBox="0 0 200 80" className="w-64 h-auto opacity-20">
          <ellipse cx="100" cy="65" rx="75" ry="8" fill="#ff6600" opacity="0.3" />
          <path d="M25,55 L30,35 L55,25 L145,25 L170,35 L175,55 Z" fill="#cc4400" />
          <path d="M60,25 L70,10 L130,10 L140,25 Z" fill="#aa3300" />
          <circle cx="55" cy="57" r="13" fill="#222" />
          <circle cx="55" cy="57" r="9" fill="#444" />
          <circle cx="145" cy="57" r="13" fill="#222" />
          <circle cx="145" cy="57" r="9" fill="#444" />
          <rect x="150" y="38" width="18" height="8" rx="2" fill="#ff4400" opacity="0.9" />
          <rect x="32" y="38" width="18" height="8" rx="2" fill="#ffffff" opacity="0.7" />
        </svg>
        {/* Speed lines */}
        <div className="absolute inset-0 -left-32 flex flex-col justify-center gap-1.5 opacity-30">
          {[0, 1, 2, 3, 4].map(i => (
            <div key={i} className="h-px bg-gradient-to-r from-transparent to-orange-500"
              style={{ width: `${60 + i * 15}px`, opacity: 0.6 - i * 0.1 }} />
          ))}
        </div>
      </div>
    </div>
  );
}

function StatBar({ label, value, max = 10, color }: { label: string; value: number; max?: number; color: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-white/40 text-xs w-16 text-right">{label}</span>
      <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${(value / max) * 100}%`, background: color }}
        />
      </div>
      <span className="text-white/60 text-xs w-4">{value}</span>
    </div>
  );
}

export function MainMenu() {
  const { setGameState, selectedCar, cars } = useGameStore();
  const [activeItem, setActiveItem] = useState(0);
  const [loadingItem, setLoadingItem] = useState<string | null>(null);
  const [particles] = useState(() =>
    Array.from({ length: 30 }, (_, i) => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 1 + Math.random() * 2,
      speed: 0.5 + Math.random() * 1,
      opacity: 0.1 + Math.random() * 0.4,
    }))
  );

  const handleMenuClick = (id: string) => {
    setLoadingItem(id);
    setTimeout(() => {
      if (id === "play" || id === "drift" || id === "police" || id === "career") {
        setGameState("loading");
        setTimeout(() => setGameState("playing"), 2500);
      } else if (id === "garage") {
        setGameState("garage");
      }
      setLoadingItem(null);
    }, 300);
  };

  return (
    <div className="fixed inset-0 menu-bg overflow-hidden">
      {/* Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map((p, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-orange-500"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: `${p.size}px`,
              height: `${p.size}px`,
              opacity: p.opacity,
            }}
          />
        ))}
      </div>

      {/* Scanlines overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.02]"
        style={{ backgroundImage: "repeating-linear-gradient(0deg, #fff 0px, #fff 1px, transparent 1px, transparent 4px)" }} />

      {/* Gradient accent */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-orange-500 to-transparent opacity-60" />

      <div className="relative h-full flex">
        {/* Left panel */}
        <div className="w-80 flex flex-col justify-between p-8 border-r border-white/5">
          {/* Logo */}
          <div>
            <div className="mb-2">
              <span className="text-orange-500 text-xs font-bold tracking-[0.3em] uppercase">World Racing</span>
            </div>
            <h1 className="text-white font-black text-4xl leading-none tracking-tight">
              HYPER<br />
              <span className="text-orange-500 neon-text">DRIFT</span><br />
              LEGENDS
            </h1>
            <div className="mt-4 h-px bg-gradient-to-r from-orange-500/50 to-transparent" />
            <p className="mt-3 text-white/30 text-xs leading-relaxed">
              Open World Street Racing<br />
              Feel the asphalt. Own the night.
            </p>
          </div>

          {/* Menu items */}
          <nav className="flex flex-col gap-2">
            {MENU_ITEMS.map((item, i) => (
              <button
                key={item.id}
                className={`menu-card px-4 py-3 rounded-xl text-left flex items-center gap-3 transition-all ${
                  activeItem === i ? "border-orange-500/50 bg-orange-500/10" : ""
                }`}
                onMouseEnter={() => setActiveItem(i)}
                onClick={() => handleMenuClick(item.id)}
              >
                <span className="text-xl">{item.icon}</span>
                <div>
                  <div className="text-white font-bold text-sm">{item.label}</div>
                  <div className="text-white/40 text-xs">{item.desc}</div>
                </div>
                {loadingItem === item.id && (
                  <div className="ml-auto w-4 h-4 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
                )}
              </button>
            ))}
          </nav>

          {/* Bottom info */}
          <div className="text-white/20 text-xs">
            <div>v1.0.0 — Hyper Drift Legends</div>
            <div className="mt-1">© 2025 World Racing Studios</div>
          </div>
        </div>

        {/* Right panel */}
        <div className="flex-1 flex flex-col p-8">
          {/* Top stats */}
          <div className="flex gap-4 mb-6">
            {[
              { label: "Best Time", value: "--:--", icon: "⏱" },
              { label: "Total XP", value: "0", icon: "⭐" },
              { label: "Coins", value: "99,999", icon: "🪙" },
            ].map((stat, i) => (
              <div key={i} className="hud-panel px-4 py-3 rounded-xl flex-1">
                <div className="text-white/40 text-xs">{stat.icon} {stat.label}</div>
                <div className="text-white font-bold text-lg mt-1">{stat.value}</div>
              </div>
            ))}
          </div>

          {/* Featured car preview */}
          <div className="flex-1 hud-panel rounded-2xl p-6 flex flex-col">
            <div className="text-orange-500 text-xs font-bold tracking-widest mb-4">SELECTED VEHICLE</div>

            {/* Car display */}
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                {/* Car icon/preview */}
                <div
                  className="w-48 h-32 mx-auto rounded-xl mb-4 flex items-center justify-center text-7xl"
                  style={{
                    background: `radial-gradient(ellipse at center, ${selectedCar.color}22 0%, transparent 70%)`,
                    border: `1px solid ${selectedCar.color}44`,
                    boxShadow: `0 0 40px ${selectedCar.color}33`,
                  }}
                >
                  🏎
                </div>

                <div
                  className="inline-block w-24 h-6 rounded mb-3 opacity-80"
                  style={{ background: selectedCar.color, boxShadow: `0 0 15px ${selectedCar.color}` }}
                />

                <h3 className="text-white font-black text-2xl">{selectedCar.brand}</h3>
                <p className="text-white/50 text-sm mb-1">{selectedCar.name}</p>
                <p className="text-white/30 text-xs italic mb-6">{selectedCar.description}</p>

                {/* Stats */}
                <div className="flex flex-col gap-2 text-left max-w-48 mx-auto">
                  <StatBar label="Top Speed" value={selectedCar.topSpeed / 34} max={10} color="#ff4400" />
                  <StatBar label="Accel" value={selectedCar.acceleration} max={10} color="#ff8800" />
                  <StatBar label="Handling" value={selectedCar.handling} max={10} color="#00aaff" />
                  <StatBar label="Turbo" value={selectedCar.turbo} max={10} color="#aa44ff" />
                </div>

                <div className="mt-4 text-orange-400 text-sm font-bold">{selectedCar.topSpeed} km/h max</div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex gap-3 mt-4">
              <button
                className="flex-1 py-4 rounded-xl font-black text-lg tracking-wide transition-all"
                style={{
                  background: "linear-gradient(135deg, #ff6600, #ff2200)",
                  boxShadow: "0 4px 20px rgba(255, 80, 0, 0.5)",
                  color: "white",
                }}
                onClick={() => {
                  setGameState("loading");
                  setTimeout(() => setGameState("playing"), 2500);
                }}
              >
                🏁 RACE NOW
              </button>
              <button
                className="px-6 py-4 rounded-xl font-bold text-sm border border-white/20 text-white/70 hover:border-white/40 hover:text-white transition-all"
                onClick={() => setGameState("garage")}
              >
                🔧 Garage
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
