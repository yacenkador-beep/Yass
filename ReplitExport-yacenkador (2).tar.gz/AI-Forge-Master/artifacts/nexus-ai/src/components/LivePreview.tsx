import { useState } from "react";
import { Copy, Play, Laptop, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProjectFile } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";

interface LivePreviewProps {
  previewUrl?: string | null;
  files: ProjectFile[];
}

export function LivePreview({ previewUrl, files }: LivePreviewProps) {
  const [viewMode, setViewMode] = useState<"desktop" | "mobile">("desktop");
  const { toast } = useToast();

  const handleCopyCode = () => {
    const allCode = files.map((f) => `/* ${f.name} */\n${f.content}`).join("\n\n");
    void navigator.clipboard.writeText(allCode);
    toast({ title: "Copied to clipboard", description: "All project files have been copied." });
  };

  // Use srcdoc so the iframe gets a null origin — never allow-same-origin on AI-generated content
  const previewSrcdoc = previewUrl ?? (() => {
    const htmlFile = files.find((f) => f.name === "index.html" || f.name.endsWith(".html"));
    return htmlFile?.content ?? null;
  })();

  return (
    <div className="flex flex-col h-full bg-[#050510] border border-white/10 rounded-xl overflow-hidden shadow-2xl relative">
      <div className="flex items-center justify-between px-4 py-2 bg-black/40 border-b border-white/10 backdrop-blur-md z-10">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full bg-destructive/80" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <div className="w-3 h-3 rounded-full bg-green-500/80" />
          </div>
          <div className="flex bg-black/40 rounded-lg p-0.5 border border-white/5">
            <Button
              variant="ghost"
              size="sm"
              className={`h-7 px-2 rounded-md ${viewMode === "desktop" ? "bg-white/10 text-white" : "text-muted-foreground"}`}
              onClick={() => setViewMode("desktop")}
            >
              <Laptop className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className={`h-7 px-2 rounded-md ${viewMode === "mobile" ? "bg-white/10 text-white" : "text-muted-foreground"}`}
              onClick={() => setViewMode("mobile")}
            >
              <Smartphone className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={handleCopyCode} className="h-8 text-muted-foreground hover:text-white">
          <Copy className="w-4 h-4 mr-2" /> Copy All
        </Button>
      </div>

      <div className="flex-1 bg-white/5 relative flex items-center justify-center overflow-hidden p-4">
        {previewSrcdoc ? (
          <div
            className={`transition-all duration-300 ${
              viewMode === "mobile"
                ? "w-[375px] h-[812px] border-[8px] border-black rounded-[2rem] shadow-2xl"
                : "w-full h-full rounded-md"
            } bg-white overflow-hidden`}
          >
            {/* srcdoc gives the iframe a null origin — safe for untrusted AI-generated HTML.
                allow-scripts is needed for JS; allow-same-origin is intentionally omitted. */}
            <iframe
              srcDoc={previewSrcdoc}
              className="w-full h-full border-0 bg-white"
              title="Live Preview"
              sandbox="allow-scripts allow-forms allow-popups"
              data-testid="iframe-preview"
            />
          </div>
        ) : (
          <div className="text-center text-muted-foreground flex flex-col items-center">
            <Play className="w-12 h-12 mb-4 opacity-20" />
            <p>No visual preview available</p>
            <p className="text-sm opacity-50">Generate a web project to see it here</p>
          </div>
        )}
      </div>
    </div>
  );
}
