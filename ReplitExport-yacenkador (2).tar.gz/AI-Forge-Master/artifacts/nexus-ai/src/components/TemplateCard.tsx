import { motion } from "framer-motion";
import { Template } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

interface TemplateCardProps {
  template: Template;
}

export function TemplateCard({ template }: TemplateCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -4 }}
      className="flex flex-col h-full rounded-2xl bg-card border border-card-border overflow-hidden group relative"
    >
      {/* Decorative gradient blob */}
      <div className="absolute -top-16 -right-16 w-32 h-32 bg-primary/20 rounded-full blur-3xl group-hover:bg-primary/30 transition-colors" />

      {template.thumbnail ? (
        <div className="h-40 w-full bg-muted border-b border-card-border relative overflow-hidden">
          <img src={template.thumbnail} alt={template.name} className="object-cover w-full h-full opacity-80 group-hover:opacity-100 transition-opacity" />
        </div>
      ) : (
        <div className="h-32 w-full bg-gradient-to-br from-white/5 to-white/10 border-b border-card-border flex items-center justify-center relative overflow-hidden">
           <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiPjxyZWN0IHdpZHRoPSI4IiBoZWlnaHQ9IjgiIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNCIvPjwvc3ZnPg==')] opacity-50" />
           <span className="text-4xl opacity-20 font-bold tracking-tighter">{template.category}</span>
        </div>
      )}

      <div className="p-5 flex flex-col flex-1 relative z-10">
        <div className="flex justify-between items-start mb-2">
          <span className="px-2 py-0.5 rounded text-xs font-mono bg-white/10 text-white/80">
            {template.type}
          </span>
          <span className="text-xs font-medium text-muted-foreground bg-muted/50 px-2 py-0.5 rounded">
            {template.category}
          </span>
        </div>

        <h3 className="text-xl font-bold text-foreground mb-2">{template.name}</h3>
        <p className="text-sm text-muted-foreground mb-4 flex-1 line-clamp-2">
          {template.description}
        </p>

        {template.tags && template.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {template.tags.slice(0, 3).map((tag, idx) => (
              <span key={idx} className="text-xs text-muted-foreground">#{tag}</span>
            ))}
          </div>
        )}

        <Link href={`/workspace?templateId=${template.id}`}>
          <Button className="w-full bg-white/10 text-white hover:bg-primary hover:text-primary-foreground transition-all">
            Use Template <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </Link>
      </div>
    </motion.div>
  );
}
