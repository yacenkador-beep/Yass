import { motion } from "framer-motion";
import { format } from "date-fns";
import { Box, Code, Gamepad2, Layout, MoreVertical, Trash, ExternalLink } from "lucide-react";
import { Project } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Link } from "wouter";

interface ProjectCardProps {
  project: Project;
  onDelete: (id: string) => void;
}

const typeIcons: Record<string, React.ElementType> = {
  app: Layout,
  website: Box,
  game: Gamepad2,
  api: Code,
  mobile: Layout,
};

const statusColors: Record<string, string> = {
  ready: "bg-primary/20 text-primary border-primary/50",
  generating: "bg-secondary/20 text-secondary border-secondary/50",
  error: "bg-destructive/20 text-destructive border-destructive/50",
};

export function ProjectCard({ project, onDelete }: ProjectCardProps) {
  const Icon = typeIcons[project.type.toLowerCase()] || Box;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      className="group flex flex-col justify-between p-5 rounded-xl bg-card border border-card-border hover:border-primary/50 transition-all backdrop-blur-xl relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      
      <div className="flex justify-between items-start mb-4 relative z-10">
        <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
          <Icon className="w-5 h-5 text-foreground" />
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-popover border-popover-border">
            <DropdownMenuItem className="text-destructive focus:text-destructive focus:bg-destructive/10" onClick={() => onDelete(project.id)}>
              <Trash className="w-4 h-4 mr-2" />
              Delete Project
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="relative z-10">
        <h3 className="text-lg font-bold text-foreground mb-1 truncate" title={project.name}>{project.name}</h3>
        <p className="text-xs text-muted-foreground mb-4">
          Created {format(new Date(project.createdAt), "MMM d, yyyy")}
        </p>
      </div>

      <div className="flex items-center justify-between mt-auto relative z-10">
        <div className={`px-2.5 py-1 rounded-full text-xs font-medium border ${statusColors[project.status] || "bg-muted text-muted-foreground"}`}>
          {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
        </div>
        
        {project.status === "ready" && (
          <Link href={`/workspace?projectId=${project.id}`}>
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary hover:bg-primary/10">
              Open <ExternalLink className="w-3 h-3 ml-2" />
            </Button>
          </Link>
        )}
      </div>
    </motion.div>
  );
}
