import { Link, useLocation } from "wouter";
import { useClerk, useUser } from "@clerk/react";
import {
  LayoutDashboard,
  MessageSquare,
  Layout,
  Gamepad2,
  Globe,
  Image,
  Code,
  Library,
  Rocket,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useLanguage } from "@/contexts/LanguageContext";

export function Sidebar() {
  const [location] = useLocation();
  const { user } = useUser();
  const { signOut } = useClerk();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { t } = useLanguage();

  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

  type NavItem = { href: string; label: string; icon: React.ElementType; match?: string };
  type NavGroup = { label: string; items: NavItem[] };

  const navGroups: NavGroup[] = [
    {
      label: "Overview",
      items: [
        { href: "/dashboard", label: t.nav.dashboard, icon: LayoutDashboard },
      ],
    },
    {
      label: "AI Tools",
      items: [
        { href: "/chat", label: t.nav.aiChat, icon: MessageSquare },
        { href: "/workspace?type=app", label: t.nav.appBuilder, icon: Layout, match: "/workspace" },
        { href: "/workspace?type=game", label: t.nav.gameBuilder, icon: Gamepad2 },
        { href: "/workspace?type=website", label: t.nav.websiteBuilder, icon: Globe },
        { href: "/workspace?type=image", label: t.nav.imageGenerator, icon: Image },
        { href: "/workspace?type=code", label: t.nav.codeGenerator, icon: Code },
      ],
    },
    {
      label: "Resources",
      items: [
        { href: "/templates", label: t.nav.templates, icon: Library },
        { href: "/deployments", label: t.nav.deployments, icon: Rocket },
      ],
    },
  ];

  const isActive = (href: string, match?: string) => {
    const base = match ?? href.split("?")[0];
    if (base === "/workspace") {
      if (location !== "/workspace") return false;
      const hrefParams = new URLSearchParams(href.split("?")[1] ?? "");
      const currentParams = new URLSearchParams(window.location.search);
      return hrefParams.get("type") === currentParams.get("type");
    }
    return location === base;
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-sidebar border-r border-sidebar-border w-64 z-40">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center border border-primary/40 shadow-[0_0_12px_rgba(0,212,255,0.25)]">
          <img src={`${basePath}/logo.svg`} alt="Nexus AI" className="w-5 h-5" />
        </div>
        <span className="font-bold text-xl tracking-tight text-foreground">Nexus AI</span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-5">
        {navGroups.map((group) => (
          <div key={group.label}>
            <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-muted-foreground/50 px-3 mb-2">
              {group.label}
            </p>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = isActive(item.href, item.match);
                return (
                  <Link key={item.href} href={item.href} onClick={() => setIsMobileOpen(false)}>
                    <div
                      className={cn(
                        "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 cursor-pointer group",
                        active
                          ? "bg-primary/10 text-primary border border-primary/20 shadow-[inset_2px_0_0_rgba(0,212,255,0.8)]"
                          : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                      )}
                      data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      <item.icon className={cn("w-4 h-4 flex-shrink-0", active ? "text-primary" : "")} />
                      <span className="text-sm font-medium flex-1">{item.label}</span>
                      {active && <ChevronRight className="w-3 h-3 text-primary/60" />}
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Settings + User */}
      <div className="border-t border-sidebar-border px-3 py-4 space-y-2">
        <Link href="/settings" onClick={() => setIsMobileOpen(false)}>
          <div
            className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-150 cursor-pointer",
              location === "/settings"
                ? "bg-primary/10 text-primary border border-primary/20"
                : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
            )}
            data-testid="nav-settings"
          >
            <Settings className="w-4 h-4 flex-shrink-0" />
            <span className="text-sm font-medium">{t.nav.settings}</span>
          </div>
        </Link>

        <div className="flex items-center gap-3 px-3 py-3 mt-2 rounded-lg bg-white/3 border border-white/5">
          <Avatar className="w-8 h-8 border border-white/10 flex-shrink-0">
            <AvatarImage src={user?.imageUrl} />
            <AvatarFallback className="bg-primary/20 text-primary text-xs">
              {user?.firstName?.charAt(0) ?? "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium truncate">{user?.fullName ?? "User"}</p>
            <p className="text-[10px] text-muted-foreground truncate">
              {user?.primaryEmailAddress?.emailAddress ?? ""}
            </p>
          </div>
          <button
            onClick={() => void signOut({ redirectUrl: basePath || "/" })}
            className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0"
            title={t.nav.signOut}
            data-testid="button-sign-out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden fixed top-4 left-4 z-50 bg-background/60 backdrop-blur-md border border-white/10"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
        data-testid="button-mobile-menu"
      >
        {isMobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </Button>

      {/* Desktop Sidebar */}
      <div className="hidden md:block h-screen sticky top-0 flex-shrink-0">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar Overlay */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setIsMobileOpen(false)} />
          <div className="relative w-64 max-w-[80%] h-full flex flex-col shadow-2xl animate-in slide-in-from-left duration-200">
            <SidebarContent />
          </div>
        </div>
      )}
    </>
  );
}
