import { ProjectFile } from "@workspace/api-client-react";
import { FileCode, FileJson, FileText, FileImage, Folder, ChevronRight, ChevronDown } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface FileExplorerProps {
  files: ProjectFile[];
  onSelectFile: (file: ProjectFile) => void;
  selectedFileName?: string;
}

export function FileExplorer({ files, onSelectFile, selectedFileName }: FileExplorerProps) {
  // Simple flat list for now, ideally this would build a tree
  return (
    <div className="flex flex-col h-full bg-sidebar border-r border-sidebar-border overflow-hidden">
      <div className="p-3 border-b border-sidebar-border bg-black/20 text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
        <Folder className="w-4 h-4 text-primary" />
        Project Files
      </div>
      
      <div className="flex-1 overflow-auto p-2 space-y-0.5">
        {files.map((file) => {
          const isSelected = file.name === selectedFileName;
          
          let FileIcon = FileText;
          if (file.name.endsWith('.ts') || file.name.endsWith('.tsx') || file.name.endsWith('.js') || file.name.endsWith('.jsx')) FileIcon = FileCode;
          else if (file.name.endsWith('.json')) FileIcon = FileJson;
          else if (file.name.endsWith('.css') || file.name.endsWith('.html')) FileIcon = FileCode;
          else if (file.name.match(/\.(png|jpe?g|svg|gif)$/i)) FileIcon = FileImage;

          return (
            <button
              key={file.name}
              onClick={() => onSelectFile(file)}
              className={cn(
                "w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors text-left",
                isSelected 
                  ? "bg-primary/20 text-primary" 
                  : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              )}
            >
              <FileIcon className={cn("w-4 h-4", isSelected ? "text-primary" : "text-muted-foreground/70")} />
              <span className="truncate flex-1">{file.name}</span>
            </button>
          );
        })}
        {files.length === 0 && (
          <div className="p-4 text-center text-sm text-muted-foreground">
            No files generated yet.
          </div>
        )}
      </div>
    </div>
  );
}
