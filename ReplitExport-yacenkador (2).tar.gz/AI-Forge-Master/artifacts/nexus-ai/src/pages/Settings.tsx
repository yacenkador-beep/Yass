import { Sidebar } from "@/components/Sidebar";
import { useUser } from "@clerk/react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useTheme } from "next-themes";
import { toast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import type { Language } from "@/lib/i18n";

export default function Settings() {
  const { user } = useUser();
  const { theme, setTheme } = useTheme();
  const { t, language, setLanguage } = useLanguage();

  const handleSavePreferences = () => {
    toast({ title: t.settings.saved });
  };

  return (
    <div className="flex h-screen bg-background text-foreground">
      <Sidebar />
      <main className="flex-1 overflow-auto p-8 lg:p-12 relative">
        <div className="max-w-4xl mx-auto space-y-12">
          <div>
            <h1 className="text-4xl font-black tracking-tight mb-2">{t.settings.title}</h1>
            <p className="text-muted-foreground">{t.settings.subtitle}</p>
          </div>

          {/* Account Profile */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold border-b border-border pb-2">{t.settings.account}</h2>
            <div className="flex items-start gap-6 p-6 rounded-2xl bg-card border border-border backdrop-blur-sm">
              <Avatar className="w-20 h-20 border-2 border-primary/20">
                <AvatarImage src={user?.imageUrl} />
                <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                  {user?.firstName?.charAt(0) ?? "U"}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>First Name</Label>
                    <Input disabled value={user?.firstName ?? ""} className="bg-white/5 border-white/10" />
                  </div>
                  <div className="space-y-2">
                    <Label>Last Name</Label>
                    <Input disabled value={user?.lastName ?? ""} className="bg-white/5 border-white/10" />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>Email Address</Label>
                    <Input disabled value={user?.primaryEmailAddress?.emailAddress ?? ""} className="bg-white/5 border-white/10" />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">Profile information is managed via Clerk authentication.</p>
              </div>
            </div>
          </div>

          {/* Platform Preferences */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold border-b border-border pb-2">{t.settings.preferences}</h2>
            <div className="p-6 rounded-2xl bg-card border border-border backdrop-blur-sm space-y-6">

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">{t.settings.appearance}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings.appearanceDesc}</p>
                </div>
                <Select value={theme} onValueChange={setTheme}>
                  <SelectTrigger className="w-[180px] bg-white/5 border-white/10" data-testid="select-theme">
                    <SelectValue placeholder="Select theme" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Language selector — changes UI language instantly */}
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">{t.settings.language}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings.languageDesc}</p>
                </div>
                <Select value={language} onValueChange={(v) => setLanguage(v as Language)}>
                  <SelectTrigger className="w-[180px] bg-white/5 border-white/10" data-testid="select-language">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ar">العربية (Arabic)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">{t.settings.aiModel}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings.aiModelDesc}</p>
                </div>
                <Select defaultValue="gpt-4.1">
                  <SelectTrigger className="w-[180px] bg-white/5 border-white/10">
                    <SelectValue placeholder="Select model" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="gpt-4.1">GPT-4.1 (Default)</SelectItem>
                    <SelectItem value="gpt-4o">GPT-4o</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={handleSavePreferences} className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_15px_rgba(0,212,255,0.2)]" data-testid="button-save-settings">
                {t.settings.save}
              </Button>
            </div>
          </div>

          {/* Notifications */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold border-b border-border pb-2">{t.settings.notifications}</h2>
            <div className="p-6 rounded-2xl bg-card border border-border backdrop-blur-sm space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-medium">{t.settings.generationComplete}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings.generationCompleteDesc}</p>
                </div>
                <Switch defaultChecked data-testid="switch-generation-complete" />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base font-medium">{t.settings.marketing}</Label>
                  <p className="text-sm text-muted-foreground">{t.settings.marketingDesc}</p>
                </div>
                <Switch data-testid="switch-marketing" />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
