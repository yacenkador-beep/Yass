import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { ParticleBackground } from "@/components/ParticleBackground";
import { Button } from "@/components/ui/button";
import { Terminal, Code, Image as ImageIcon, Layout, Gamepad2, ArrowRight, Zap, Star, Check } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

const features = [
  { icon: Layout, title: "App Builder", desc: "Generate full-stack web applications with database schema, APIs, and responsive frontend.", color: "text-primary", type: "app" },
  { icon: Gamepad2, title: "Game Creator", desc: "Build playable browser games with physics, graphics, and state management.", color: "text-secondary", type: "game" },
  { icon: Terminal, title: "Website Generator", desc: "Create stunning landing pages and marketing sites tailored to your brand.", color: "text-accent", type: "website" },
  { icon: Code, title: "Code Assistant", desc: "Write, refactor, and debug complex algorithms across any language.", color: "text-primary", type: "code" },
  { icon: ImageIcon, title: "Image Studio", desc: "Generate bespoke visuals, icons, and assets integrated directly into your projects.", color: "text-secondary", type: "image" },
  { icon: Zap, title: "Instant Deploy", desc: "Push your generated projects live to a global CDN with a single click.", color: "text-accent", type: null },
];

const templates = [
  { name: "SaaS Dashboard", type: "App", desc: "A complete B2B dashboard with charts, tables, and auth." },
  { name: "E-Commerce Store", type: "Website", desc: "A modern storefront with cart and checkout flows." },
  { name: "Platformer Game", type: "Game", desc: "A 2D platformer with jumping mechanics and level design." },
  { name: "Portfolio Site", type: "Website", desc: "A personal showcase with interactive project galleries." },
  { name: "Chat Application", type: "App", desc: "Real-time messaging interface with channels and DMs." },
  { name: "REST API Server", type: "Code", desc: "A robust Node.js backend with routing and controllers." },
];

const examplePrompts = [
  "Build a task management app with drag-and-drop boards",
  "Create a landing page for a coffee shop with dark mode",
  "Generate a 2D space shooter game with power-ups",
  "Write a Python API for user authentication with JWT",
];

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Founder, Launchpad Studio",
    quote: "Nexus AI cut our MVP time from 3 weeks to 2 days. The generated code is actually production-quality — we shipped it without a single refactor.",
    rating: 5,
  },
  {
    name: "Marcus Wright",
    role: "Indie Game Developer",
    quote: "I built a fully playable browser game in 20 minutes. The physics, level design, enemy AI — all generated from a single prompt. Mind-blowing.",
    rating: 5,
  },
  {
    name: "Priya Nair",
    role: "Lead Engineer, Fintech Co.",
    quote: "We use Nexus AI to prototype internal tools and dashboards. It's become the first tool we reach for whenever a new stakeholder request comes in.",
    rating: 5,
  },
];

const pricingTiers = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    desc: "Perfect for exploring Nexus AI",
    features: ["10 AI generations / month", "App, website & code builder", "Community templates", "Export source code"],
    cta: "Get Started",
    highlighted: false,
  },
  {
    name: "Pro",
    price: "$29",
    period: "per month",
    desc: "For creators and indie developers",
    features: ["Unlimited AI generations", "All builders incl. image & game", "Priority AI queue", "Custom domains", "Advanced templates", "1-click deploy"],
    cta: "Start Free Trial",
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "contact us",
    desc: "For teams and organizations",
    features: ["Everything in Pro", "Team workspaces", "SSO & SAML", "Dedicated support", "SLA guarantee", "On-premise option"],
    cta: "Contact Sales",
    highlighted: false,
  },
];

export default function Landing() {
  const [, navigate] = useLocation();
  const [userPrompt, setUserPrompt] = useState("");
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const { t } = useLanguage();

  const handleGenerate = () => {
    const q = userPrompt.trim() || examplePrompts[placeholderIndex] || "";
    navigate(`/sign-up`);
    // Store prompt so workspace can pick it up after sign-up
    if (q) sessionStorage.setItem("nexus_pending_prompt", q);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handleGenerate();
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden font-sans">
      <ParticleBackground />

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-4 max-w-7xl mx-auto backdrop-blur-sm border-b border-white/5 rounded-b-2xl mb-8">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center border border-primary/50 shadow-[0_0_15px_rgba(0,212,255,0.4)]">
            <img src={`${basePath}/logo.svg`} alt="Nexus" className="w-5 h-5" />
          </div>
          <span className="font-bold text-xl tracking-tight text-white">Nexus AI</span>
        </div>
        <div className="flex items-center gap-4">
          <a href="#pricing" className="text-sm text-muted-foreground hover:text-white transition-colors hidden md:block">{t.landing.pricing}</a>
          <Link href="/sign-in">
            <Button variant="ghost" className="text-white hover:bg-white/10 hover:text-white" data-testid="button-sign-in">{t.landing.signIn}</Button>
          </Link>
          <Link href="/sign-up">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(0,212,255,0.3)]" data-testid="button-get-started">
              {t.landing.getStarted}
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <main className="relative z-10 max-w-7xl mx-auto px-6 pt-12 pb-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-sm text-muted-foreground mb-8 backdrop-blur-md">
            <span className="flex h-2 w-2 rounded-full bg-primary animate-pulse"></span>
            Nexus OS v2.0 is now live
          </div>

          <h1 className="text-5xl md:text-7xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-white via-white to-white/50 mb-6 leading-tight">
            {t.landing.tagline} <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-secondary to-accent filter drop-shadow-[0_0_15px_rgba(124,58,237,0.5)]">
              {t.landing.taglineAccent}
            </span>
          </h1>

          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            {t.landing.description}
          </p>

          {/* Editable hero input */}
          <div className="relative max-w-2xl mx-auto p-[1px] rounded-2xl bg-gradient-to-r from-primary/30 via-secondary/30 to-accent/30 shadow-[0_0_40px_rgba(0,212,255,0.15)] group">
            <div className="relative flex items-center bg-card rounded-2xl p-2 backdrop-blur-xl border border-white/5">
              <Terminal className="w-5 h-5 text-muted-foreground ml-3 flex-shrink-0" />
              <input
                type="text"
                value={userPrompt}
                onChange={(e) => setUserPrompt(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={examplePrompts[placeholderIndex]}
                className="flex-1 bg-transparent border-none text-white px-4 py-3 focus:outline-none placeholder:text-muted-foreground/50 font-mono text-sm"
                data-testid="input-hero-prompt"
              />
              <Button
                className="rounded-xl px-6 bg-white text-black hover:bg-white/90 flex-shrink-0"
                onClick={handleGenerate}
                data-testid="button-hero-generate"
              >
                {t.landing.generate} <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
          <div className="mt-4 flex justify-center gap-2">
            {examplePrompts.map((_, i) => (
              <button
                data-testid={`prompt-dot-${i}`}
                key={i}
                className={`w-2 h-2 rounded-full transition-all ${i === placeholderIndex ? "bg-primary w-4" : "bg-white/20"}`}
                onClick={() => setPlaceholderIndex(i)}
              />
            ))}
          </div>
        </motion.div>

        {/* Features */}
        <div className="mt-32 grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className={`p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all hover:-translate-y-1 group ${f.type ? "cursor-pointer" : ""}`}
              onClick={() => f.type && navigate(`/sign-up`)}
            >
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <f.icon className={`w-6 h-6 ${f.color}`} />
              </div>
              <h3 className="text-xl font-bold mb-2 text-white">{f.title}</h3>
              <p className="text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* How it works */}
        <div className="mt-32 mb-20 relative">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent blur-3xl -z-10"></div>
          <h2 className="text-3xl font-bold mb-16">{t.landing.howItWorks}</h2>
          <div className="flex flex-col md:flex-row gap-8 items-center justify-center">
            {[
              { step: "01", title: t.landing.prompt, desc: t.landing.promptDesc },
              { step: "02", title: t.landing.generationStep, desc: t.landing.generationStepDesc },
              { step: "03", title: t.landing.deploy, desc: t.landing.deployDesc },
            ].map((s, i) => (
              <div key={i} className="flex-1 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/20 border border-primary flex items-center justify-center text-xl font-black text-primary mx-auto mb-6 shadow-[0_0_30px_rgba(0,212,255,0.3)]">
                  {s.step}
                </div>
                <h4 className="text-xl font-bold text-white mb-2">{s.title}</h4>
                <p className="text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Templates */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold mb-12">Start from a template</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map((t, i) => (
              <div key={i} className="p-6 rounded-2xl bg-card border border-border text-left relative overflow-hidden group cursor-pointer hover:-translate-y-1 transition-transform" onClick={() => navigate("/sign-up")}>
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-primary/20 transition-all"></div>
                <span className="text-xs font-mono px-2 py-1 rounded bg-white/10 text-white/80 mb-4 inline-block">{t.type}</span>
                <h4 className="text-lg font-bold text-white mb-2">{t.name}</h4>
                <p className="text-sm text-muted-foreground">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Testimonials */}
        <div className="mt-32">
          <h2 className="text-3xl font-bold mb-4">{t.landing.testimonials}</h2>
          <p className="text-muted-foreground mb-16 max-w-xl mx-auto">Join thousands of developers, designers, and entrepreneurs who ship 10x faster with Nexus AI.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
            {testimonials.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.12 }}
                viewport={{ once: true }}
                className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm flex flex-col gap-4"
              >
                <div className="flex gap-1">
                  {Array.from({ length: item.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-muted-foreground flex-1 italic">"{item.quote}"</p>
                <div>
                  <p className="font-semibold text-white">{item.name}</p>
                  <p className="text-xs text-muted-foreground">{item.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Pricing */}
        <div id="pricing" className="mt-32 scroll-mt-8">
          <h2 className="text-3xl font-bold mb-4">{t.landing.pricingTitle}</h2>
          <p className="text-muted-foreground mb-16 max-w-xl mx-auto">{t.landing.pricingSubtitle}</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            {pricingTiers.map((tier, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className={`p-8 rounded-2xl text-left relative overflow-hidden flex flex-col ${
                  tier.highlighted
                    ? "bg-gradient-to-b from-primary/20 to-secondary/10 border border-primary/40 shadow-[0_0_40px_rgba(0,212,255,0.15)] scale-105"
                    : "bg-white/5 border border-white/10"
                }`}
              >
                {tier.highlighted && (
                  <div className="absolute top-4 right-4 px-2 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold">Most Popular</div>
                )}
                <div className="mb-6">
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-widest mb-2">{tier.name}</p>
                  <div className="flex items-end gap-2 mb-2">
                    <span className="text-4xl font-black text-white">{tier.price}</span>
                    <span className="text-muted-foreground pb-1">/{tier.period}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{tier.desc}</p>
                </div>
                <ul className="flex-1 space-y-3 mb-8">
                  {tier.features.map((feature, j) => (
                    <li key={j} className="flex items-center gap-3 text-sm">
                      <Check className={`w-4 h-4 flex-shrink-0 ${tier.highlighted ? "text-primary" : "text-muted-foreground"}`} />
                      <span className="text-foreground/80">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/sign-up">
                  <Button
                    className={`w-full ${
                      tier.highlighted
                        ? "bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(0,212,255,0.3)]"
                        : "bg-white/10 hover:bg-white/20 text-white border border-white/10"
                    }`}
                    data-testid={`pricing-cta-${tier.name.toLowerCase()}`}
                  >
                    {tier.cta}
                  </Button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 py-12 mt-20 backdrop-blur-md bg-background/50">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <img src={`${basePath}/logo.svg`} alt="Nexus" className="w-6 h-6 grayscale opacity-50" />
            <span className="text-muted-foreground font-medium">Nexus AI &copy; 2025</span>
          </div>
          <div className="flex gap-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#pricing" className="hover:text-white transition-colors">{t.landing.pricing}</a>
            <a href="#" className="hover:text-white transition-colors">GitHub</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
