import { Sidebar } from "@/components/Sidebar";
import { ProjectCard } from "@/components/ProjectCard";
import { 
  useGetDashboardStats, 
  useListProjects, 
  useGetRecentActivity,
  useDeleteProject,
  useCreateProject,
  getListProjectsQueryKey,
  getGetDashboardStatsQueryKey,
  getGetRecentActivityQueryKey,
  Project
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Plus, Layout, Gamepad2, Code, Box, Activity } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Link, useLocation } from "wouter";

export default function Dashboard() {
  const { data: stats } = useGetDashboardStats();
  const { data: projects = [], isLoading: isLoadingProjects } = useListProjects();
  const { data: activity = [] } = useGetRecentActivity();
  const deleteProject = useDeleteProject();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleDelete = (id: string) => {
    deleteProject.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Project deleted" });
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardStatsQueryKey() });
      },
      onError: () => {
        toast({ title: "Failed to delete project", variant: "destructive" });
      }
    });
  };

  const handleQuickAction = (type: string) => {
    setLocation(`/workspace?type=${type}`);
  };

  return (
    <div className="flex h-screen bg-background text-foreground">
      <Sidebar />
      <main className="flex-1 overflow-auto p-8 lg:p-12 relative">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[100px] -z-10 pointer-events-none" />
        
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
            <div>
              <h1 className="text-4xl font-black tracking-tight mb-2">Dashboard</h1>
              <p className="text-muted-foreground">Welcome to your Nexus AI command center.</p>
            </div>
            <Link href="/workspace">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(0,212,255,0.3)]">
                <Plus className="w-4 h-4 mr-2" />
                New Generation
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {[
              { label: "Total Projects", value: stats?.totalProjects || 0, icon: Box, color: "text-primary" },
              { label: "AI Generations", value: stats?.totalGenerations || 0, icon: Activity, color: "text-secondary" },
              { label: "Saved Templates", value: stats?.savedTemplates || 0, icon: Layout, color: "text-accent" },
              { label: "Deployments", value: stats?.activeDeployments || 0, icon: Code, color: "text-green-500" }
            ].map((stat, i) => (
              <div key={i} className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md relative overflow-hidden group hover:border-white/20 transition-colors">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-muted-foreground font-medium mb-2">{stat.label}</p>
                    <h3 className="text-3xl font-bold">{stat.value}</h3>
                  </div>
                  <div className={`p-3 rounded-xl bg-white/5 ${stat.color}`}>
                    <stat.icon className="w-5 h-5" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <h2 className="text-xl font-bold mb-6">Quick Actions</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {[
              { label: "New App", icon: Layout, type: "app" },
              { label: "New Website", icon: Box, type: "website" },
              { label: "New Game", icon: Gamepad2, type: "game" },
              { label: "Generate Code", icon: Code, type: "code" }
            ].map((action, i) => (
              <Button 
                key={i} 
                variant="outline" 
                className="h-auto py-6 flex flex-col items-center gap-3 bg-white/5 hover:bg-white/10 border-white/10 hover:border-primary/50 transition-all group"
                onClick={() => handleQuickAction(action.type)}
              >
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center group-hover:scale-110 group-hover:text-primary transition-all">
                  <action.icon className="w-5 h-5" />
                </div>
                <span>{action.label}</span>
              </Button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">Recent Projects</h2>
                <Link href="/workspace">
                  <Button variant="ghost" size="sm" className="text-primary">View All</Button>
                </Link>
              </div>

              {isLoadingProjects ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className="h-48 rounded-xl bg-white/5 animate-pulse border border-white/10" />
                  ))}
                </div>
              ) : projects.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {projects.slice(0, 4).map(project => (
                    <ProjectCard key={project.id} project={project} onDelete={handleDelete} />
                  ))}
                </div>
              ) : (
                <div className="p-12 text-center rounded-2xl bg-white/5 border border-white/10 border-dashed">
                  <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
                    <Box className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">No projects yet</h3>
                  <p className="text-muted-foreground mb-6">Start building your first AI-generated application.</p>
                  <Button onClick={() => handleQuickAction("app")} className="bg-primary hover:bg-primary/90">
                    Create your first project
                  </Button>
                </div>
              )}
            </div>

            <div>
              <h2 className="text-xl font-bold mb-6">Recent Activity</h2>
              <div className="p-6 rounded-2xl bg-white/5 border border-white/10">
                {activity.length > 0 ? (
                  <div className="space-y-6">
                    {activity.map((item, i) => (
                      <div key={i} className="flex gap-4 relative">
                        {i !== activity.length - 1 && (
                          <div className="absolute left-2 top-8 bottom-[-24px] w-[1px] bg-white/10" />
                        )}
                        <div className="w-4 h-4 rounded-full bg-primary/20 border border-primary flex-shrink-0 mt-1 z-10" />
                        <div>
                          <p className="text-sm font-medium text-foreground">{item.description}</p>
                          <p className="text-xs text-muted-foreground mt-1">{format(new Date(item.createdAt), "MMM d, h:mm a")}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">No recent activity.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
