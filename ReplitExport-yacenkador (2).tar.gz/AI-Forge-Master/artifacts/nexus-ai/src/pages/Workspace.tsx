import { Sidebar } from "@/components/Sidebar";
import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { LivePreview } from "@/components/LivePreview";
import { FileExplorer } from "@/components/FileExplorer";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Send, Sparkles, Image as ImageIcon, Box, Layout, Gamepad2, Code, Play, Download, Copy, MessageSquare, X } from "lucide-react";
import { ProjectFile, useCreateProject, getListProjectsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

type GenerationType = "app" | "website" | "game" | "code" | "image";

const typeIcons: Record<string, React.ElementType> = {
  app: Layout,
  website: Box,
  game: Gamepad2,
  code: Code,
  image: ImageIcon,
};

type ChatEntry = { role: string; content: string };
type GenerationResult = {
  files?: ProjectFile[];
  previewUrl?: string;
  imageUrl?: string;
  code?: string;
  message?: string;
};

async function downloadZip(files: ProjectFile[], projectName: string): Promise<void> {
  const encoder = new TextEncoder();
  const localHeaders: Uint8Array[] = [];
  const centralDirs: Uint8Array[] = [];
  let offset = 0;

  function uint32LE(n: number): Uint8Array {
    const buf = new Uint8Array(4);
    new DataView(buf.buffer).setUint32(0, n, true);
    return buf;
  }

  function uint16LE(n: number): Uint8Array {
    const buf = new Uint8Array(2);
    new DataView(buf.buffer).setUint16(0, n, true);
    return buf;
  }

  function crc32(data: Uint8Array): number {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) {
        c = c & 1 ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      }
      table[i] = c;
    }
    let crc = 0xffffffff;
    for (const byte of data) {
      crc = table[(crc ^ byte) & 0xff]! ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const dataBytes = encoder.encode(file.content);
    const crc = crc32(dataBytes);
    const localHeader = new Uint8Array([
      ...uint32LE(0x04034b50),
      ...uint16LE(20),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint32LE(crc),
      ...uint32LE(dataBytes.length),
      ...uint32LE(dataBytes.length),
      ...uint16LE(nameBytes.length),
      ...uint16LE(0),
      ...nameBytes,
    ]);

    const centralDir = new Uint8Array([
      ...uint32LE(0x02014b50),
      ...uint16LE(20),
      ...uint16LE(20),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint32LE(crc),
      ...uint32LE(dataBytes.length),
      ...uint32LE(dataBytes.length),
      ...uint16LE(nameBytes.length),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint16LE(0),
      ...uint32LE(0),
      ...uint32LE(offset),
      ...nameBytes,
    ]);

    localHeaders.push(new Uint8Array([...localHeader, ...dataBytes]));
    centralDirs.push(centralDir);
    offset += localHeader.length + dataBytes.length;
  }

  const centralDirStart = offset;
  const centralDirSize = centralDirs.reduce((acc, d) => acc + d.length, 0);

  const eocd = new Uint8Array([
    ...uint32LE(0x06054b50),
    ...uint16LE(0),
    ...uint16LE(0),
    ...uint16LE(files.length),
    ...uint16LE(files.length),
    ...uint32LE(centralDirSize),
    ...uint32LE(centralDirStart),
    ...uint16LE(0),
  ]);

  const allParts = [...localHeaders, ...centralDirs, eocd];
  const totalLen = allParts.reduce((acc, p) => acc + p.length, 0);
  const zipBytes = new Uint8Array(totalLen);
  let pos = 0;
  for (const part of allParts) {
    zipBytes.set(part, pos);
    pos += part.length;
  }

  const blob = new Blob([zipBytes], { type: "application/zip" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${projectName.replace(/\s+/g, "-").toLowerCase()}.zip`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function Workspace() {
  const [prompt, setPrompt] = useState("");
  const [genType, setGenType] = useState<GenerationType>("app");
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [selectedFile, setSelectedFile] = useState<ProjectFile | null>(null);
  const [chatHistory, setChatHistory] = useState<ChatEntry[]>([]);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createProject = useCreateProject();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const typeParam = params.get("type");
    if (typeParam && (["app", "website", "game", "code", "image"] as string[]).includes(typeParam)) {
      setGenType(typeParam as GenerationType);
    }
    const promptParam = params.get("prompt");
    if (promptParam) {
      setPrompt(decodeURIComponent(promptParam));
    }
    // Pick up any prompt saved from the landing page
    const pendingPrompt = sessionStorage.getItem("nexus_pending_prompt");
    if (pendingPrompt) {
      setPrompt(pendingPrompt);
      sessionStorage.removeItem("nexus_pending_prompt");
    }
  }, []);

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;

    const currentPrompt = prompt;
    setIsGenerating(true);
    setResult(null);
    setSelectedFile(null);

    try {
      if (genType === "image") {
        const res = await fetch("/api/ai/image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt: currentPrompt }),
        });
        const data = (await res.json()) as { url: string };
        setResult({ imageUrl: data.url });

        // Persist image project with preview URL
        await createProject.mutateAsync({
          data: {
            name: currentPrompt.slice(0, 60),
            type: "image",
            prompt: currentPrompt,
            preview: data.url,
          },
        });
        void queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });

      } else if (genType === "code") {
        const res = await fetch("/api/ai/code", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt: currentPrompt, language: "typescript" }),
        });
        const data = (await res.json()) as { code: string; explanation: string | null };
        setResult({ code: data.code, message: data.explanation ?? undefined });

        // Persist code project with files
        await createProject.mutateAsync({
          data: {
            name: currentPrompt.slice(0, 60),
            type: "code",
            prompt: currentPrompt,
            files: [{ name: "generated.ts", content: data.code, language: "typescript" }],
          },
        });
        void queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });

      } else {
        const res = await fetch("/api/ai/build", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt: currentPrompt, type: genType }),
        });
        const data = (await res.json()) as {
          projectId: string;
          files: ProjectFile[];
          preview: string;
          summary: string | null;
        };

        setResult({ files: data.files, previewUrl: data.preview, message: data.summary ?? undefined });
        if (data.files && data.files.length > 0) {
          setSelectedFile(data.files.find((f) => f.name.includes("index")) ?? data.files[0] ?? null);
        }

        // Persist project with files + preview so Dashboard + Deployments reflect real output
        await createProject.mutateAsync({
          data: {
            name: currentPrompt.slice(0, 60),
            type: genType,
            prompt: currentPrompt,
            preview: data.preview,
            files: data.files,
          },
        });
        void queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
      }

      setChatHistory((prev) => [
        ...prev,
        { role: "user", content: currentPrompt },
        { role: "assistant", content: `Generated ${genType} project successfully.` },
      ]);
    } catch {
      toast({ title: "Generation failed", description: "Unable to reach the AI service. Please try again.", variant: "destructive" });
    } finally {
      setIsGenerating(false);
      setPrompt("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void handleGenerate();
    }
  };

  const handleCopy = (text: string) => {
    void navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  const handleDownloadZip = () => {
    if (!result?.files) return;
    void downloadZip(result.files, `nexus-${genType}`);
    toast({ title: "Downloading ZIP..." });
  };

  const TypeIcon = typeIcons[genType] ?? Code;

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />

      <main className="flex-1 flex flex-col relative bg-[#0a0a1a] overflow-hidden">
        <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[150px] pointer-events-none" />

        {/* Header / Input Area */}
        <div className="p-6 pb-2 border-b border-white/5 bg-background/80 backdrop-blur-xl z-20 relative">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-4">
              <Select value={genType} onValueChange={(val) => setGenType(val as GenerationType)}>
                <SelectTrigger className="w-[180px] bg-white/5 border-white/10 h-10" data-testid="select-gen-type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-border">
                  <SelectItem value="app"><div className="flex items-center gap-2"><Layout className="w-4 h-4" /> Web App</div></SelectItem>
                  <SelectItem value="website"><div className="flex items-center gap-2"><Box className="w-4 h-4" /> Website</div></SelectItem>
                  <SelectItem value="game"><div className="flex items-center gap-2"><Gamepad2 className="w-4 h-4" /> Game</div></SelectItem>
                  <SelectItem value="code"><div className="flex items-center gap-2"><Code className="w-4 h-4" /> Code Snippet</div></SelectItem>
                  <SelectItem value="image"><div className="flex items-center gap-2"><ImageIcon className="w-4 h-4" /> Image Asset</div></SelectItem>
                </SelectContent>
              </Select>

              <h2 className="text-lg font-bold flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                AI Studio
              </h2>

              <div className="ml-auto flex items-center gap-2">
                {result?.files && result.files.length > 0 && (
                  <Button variant="outline" size="sm" className="gap-2 border-white/10 bg-white/5 hover:bg-white/10" onClick={handleDownloadZip} data-testid="button-download-zip">
                    <Download className="w-4 h-4" />
                    Download ZIP
                  </Button>
                )}
                <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground" onClick={() => setIsChatOpen(!isChatOpen)} data-testid="button-toggle-chat">
                  <MessageSquare className="w-4 h-4" />
                  History
                </Button>
              </div>
            </div>

            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/30 to-secondary/30 rounded-xl blur opacity-30 group-focus-within:opacity-100 transition duration-500" />
              <div className="relative flex bg-card border border-white/10 rounded-xl overflow-hidden shadow-2xl">
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={`Describe the ${genType} you want to build...`}
                  className="min-h-[80px] w-full resize-none border-0 focus-visible:ring-0 bg-transparent text-white p-4 font-mono text-sm"
                  disabled={isGenerating}
                  data-testid="input-prompt"
                />
                <div className="p-3 flex flex-col justify-end bg-black/20">
                  <Button
                    onClick={() => void handleGenerate()}
                    disabled={!prompt.trim() || isGenerating}
                    className="h-10 w-10 p-0 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_15px_rgba(0,212,255,0.4)]"
                    data-testid="button-generate"
                  >
                    {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Results Area */}
        <div className="flex-1 flex overflow-hidden relative">
          <div className="flex-1 flex flex-col relative p-6 overflow-hidden">
            <AnimatePresence mode="wait">
              {isGenerating ? (
                <motion.div
                  key="generating"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col items-center justify-center bg-background/50 backdrop-blur-sm z-30"
                >
                  <div className="w-24 h-24 relative mb-6">
                    <div className="absolute inset-0 border-t-2 border-primary rounded-full animate-spin" />
                    <div className="absolute inset-2 border-r-2 border-secondary rounded-full animate-spin" style={{ animationDelay: "150ms" }} />
                    <div className="absolute inset-4 border-b-2 border-accent rounded-full animate-spin" style={{ animationDelay: "300ms" }} />
                    <Sparkles className="absolute inset-0 m-auto w-8 h-8 text-primary animate-pulse" />
                  </div>
                  <h3 className="text-xl font-bold font-mono tracking-widest text-primary animate-pulse">GENERATING...</h3>
                  <p className="text-muted-foreground mt-2 font-mono text-sm">Synthesizing neural pathways</p>
                </motion.div>
              ) : result ? (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex-1 flex gap-6 min-h-0"
                >
                  {genType === "image" && result.imageUrl ? (
                    <div className="flex-1 flex flex-col gap-4">
                      {result.message && <p className="text-sm text-muted-foreground">{result.message}</p>}
                      <div className="flex-1 flex items-center justify-center bg-black/40 border border-white/5 rounded-2xl overflow-hidden">
                        <img src={result.imageUrl} alt="Generated asset" className="max-w-full max-h-full object-contain" data-testid="img-generated" />
                      </div>
                      <Button variant="outline" size="sm" className="w-fit border-white/10 bg-white/5" onClick={() => handleCopy(result.imageUrl!)}>
                        <Copy className="w-4 h-4 mr-2" /> Copy URL
                      </Button>
                    </div>
                  ) : genType === "code" && result.code ? (
                    <div className="flex-1 flex flex-col bg-[#0d0d1a] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
                      <div className="bg-black/50 px-4 py-2 border-b border-white/10 flex justify-between items-center">
                        <span className="font-mono text-sm text-primary">Generated Code</span>
                        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => handleCopy(result.code!)} data-testid="button-copy-code">
                          <Copy className="w-3 h-3" /> Copy
                        </Button>
                      </div>
                      {result.message && (
                        <div className="px-6 pt-4 text-sm text-muted-foreground italic border-b border-white/5 pb-4">{result.message}</div>
                      )}
                      <pre className="p-6 overflow-auto font-mono text-sm text-green-400 flex-1">
                        <code>{result.code}</code>
                      </pre>
                    </div>
                  ) : result.files ? (
                    <>
                      <div className="w-64 flex-shrink-0 bg-black/20 border border-white/5 rounded-2xl overflow-hidden backdrop-blur-sm">
                        <FileExplorer
                          files={result.files}
                          onSelectFile={setSelectedFile}
                          selectedFileName={selectedFile?.name}
                        />
                      </div>
                      <div className="flex-1 flex flex-col min-w-0 bg-[#0d0d1a] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
                        {selectedFile ? (
                          <>
                            <div className="bg-black/50 px-4 py-2 border-b border-white/10 flex justify-between items-center">
                              <span className="font-mono text-sm text-white/70">{selectedFile.name}</span>
                              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => handleCopy(selectedFile.content)} data-testid="button-copy-file">
                                <Copy className="w-3 h-3" /> Copy
                              </Button>
                            </div>
                            <pre className="flex-1 p-6 overflow-auto font-mono text-sm text-[#00d4ff] leading-relaxed">
                              <code>{selectedFile.content}</code>
                            </pre>
                          </>
                        ) : (
                          <div className="flex-1 flex items-center justify-center text-muted-foreground">Select a file to view</div>
                        )}
                      </div>
                    </>
                  ) : null}
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex-1 flex flex-col items-center justify-center text-muted-foreground opacity-50"
                >
                  <TypeIcon className="w-24 h-24 mb-6" />
                  <h3 className="text-2xl font-bold text-white mb-2">Ready to Build</h3>
                  <p>Enter a prompt above to unleash Nexus AI.</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Live Preview Panel */}
          {(genType === "app" || genType === "website" || genType === "game") && result?.files && result.files.length > 0 && (
            <div className="w-[450px] xl:w-[600px] border-l border-white/5 bg-black/20 p-6 flex flex-col">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2">
                <Play className="w-4 h-4 text-secondary" /> Live Preview
              </h3>
              <div className="flex-1 min-h-0">
                <LivePreview files={result.files} previewUrl={result.previewUrl} />
              </div>
            </div>
          )}

          {/* Chat History Drawer */}
          <AnimatePresence>
            {isChatOpen && (
              <motion.div
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 250 }}
                className="absolute right-0 top-0 bottom-0 w-80 bg-card border-l border-white/10 flex flex-col z-40 shadow-2xl"
              >
                <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
                  <h3 className="font-semibold text-sm flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-primary" /> Session History
                  </h3>
                  <button onClick={() => setIsChatOpen(false)} className="text-muted-foreground hover:text-white transition-colors" data-testid="button-close-chat">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
                  {chatHistory.length === 0 ? (
                    <p className="text-muted-foreground text-sm text-center mt-8">No history yet. Generate something!</p>
                  ) : (
                    chatHistory.map((entry, i) => (
                      <div key={i} className={`rounded-xl p-3 text-sm ${entry.role === "user" ? "bg-primary/10 border border-primary/20 text-foreground" : "bg-white/5 border border-white/5 text-muted-foreground"}`} data-testid={`chat-entry-${i}`}>
                        <span className="font-semibold text-xs uppercase tracking-wider block mb-1 opacity-60">{entry.role}</span>
                        {entry.content}
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
