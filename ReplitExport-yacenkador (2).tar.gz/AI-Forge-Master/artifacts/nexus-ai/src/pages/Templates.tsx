import { Sidebar } from "@/components/Sidebar";
import { TemplateCard } from "@/components/TemplateCard";
import { useListTemplates } from "@workspace/api-client-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const CATEGORIES = ["All", "Games", "Websites", "Apps", "Code"];

export default function Templates() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  
  const { data: templates = [], isLoading } = useListTemplates({ 
    category: selectedCategory === "All" ? undefined : selectedCategory.toLowerCase() 
  });

  return (
    <div className="flex h-screen bg-background text-foreground">
      <Sidebar />
      <main className="flex-1 overflow-auto p-8 lg:p-12 relative">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-secondary/5 rounded-full blur-[120px] -z-10 pointer-events-none" />
        
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <h1 className="text-4xl font-black tracking-tight mb-4">Template Library</h1>
            <p className="text-xl text-muted-foreground max-w-2xl">
              Kickstart your generation with curated starter prompts and configurations optimized for Nexus AI.
            </p>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
            {CATEGORIES.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={cn(
                  "px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all border",
                  selectedCategory === category
                    ? "bg-white text-black border-transparent shadow-[0_0_15px_rgba(255,255,255,0.2)]"
                    : "bg-white/5 border-white/10 text-muted-foreground hover:text-white hover:bg-white/10"
                )}
              >
                {category}
              </button>
            ))}
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
                <div key={i} className="h-80 rounded-2xl bg-white/5 animate-pulse border border-white/10" />
              ))}
            </div>
          ) : templates.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {templates.map(template => (
                <TemplateCard key={template.id} template={template} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-white/5 rounded-2xl border border-white/10 border-dashed">
              <p className="text-muted-foreground">No templates found for this category.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
