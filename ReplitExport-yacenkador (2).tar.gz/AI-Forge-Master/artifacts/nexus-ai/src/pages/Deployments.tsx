import { Sidebar } from "@/components/Sidebar";
import { useListProjects, getListProjectsQueryKey } from "@workspace/api-client-react";
import { motion } from "framer-motion";
import { Rocket, Globe, CheckCircle, Clock, XCircle, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";

const STATUS_COLORS: Record<string, string> = {
  ready: "text-emerald-400",
  generating: "text-yellow-400",
  error: "text-red-400",
};

const STATUS_ICONS: Record<string, React.ElementType> = {
  ready: CheckCircle,
  generating: Clock,
  error: XCircle,
};

const TYPE_EMOJIS: Record<string, string> = {
  website: "W",
  app: "A",
  game: "G",
  api: "API",
  mobile: "M",
};

export default function Deployments() {
  const { t } = useLanguage();
  const projects = useListProjects(undefined, {
    query: { queryKey: getListProjectsQueryKey() },
  });

  const deployed = (projects.data ?? []).filter((p) => p.status === "ready" && p.preview);

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />

      <main className="flex-1 overflow-auto p-8 relative bg-[#0a0a1a]">
        <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-secondary/10 rounded-full blur-[150px] pointer-events-none" />

        <div className="max-w-5xl mx-auto relative z-10">
          <div className="mb-10">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-secondary/20 border border-secondary/30 flex items-center justify-center">
                <Rocket className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <h1 className="text-3xl font-black tracking-tight">{t.deployments.title}</h1>
                <p className="text-muted-foreground">{t.deployments.subtitle}</p>
              </div>
            </div>
          </div>

          {projects.isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-40 rounded-2xl bg-white/5 border border-white/5 animate-pulse" />
              ))}
            </div>
          ) : deployed.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-32 text-center">
              <div className="w-20 h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6">
                <Globe className="w-10 h-10 text-muted-foreground" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">{t.deployments.empty}</h2>
              <p className="text-muted-foreground mb-8 max-w-sm">{t.deployments.emptyHint}</p>
              <Link href="/workspace">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_rgba(0,212,255,0.3)]" data-testid="button-go-to-workspace">
                  <Rocket className="w-4 h-4 mr-2" />
                  Build Something
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {deployed.map((project, i) => {
                const StatusIcon = STATUS_ICONS[project.status] ?? CheckCircle;
                const statusColor = STATUS_COLORS[project.status] ?? "text-muted-foreground";
                return (
                  <motion.div
                    key={project.id}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/8 transition-all group"
                    data-testid={`deployment-card-${project.id}`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-secondary/20 border border-secondary/20 flex items-center justify-center text-xs font-bold text-secondary">
                          {TYPE_EMOJIS[project.type] ?? project.type.toUpperCase().charAt(0)}
                        </div>
                        <div>
                          <h3 className="font-bold text-white">{project.name}</h3>
                          <p className="text-xs text-muted-foreground">{new Date(project.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className={`flex items-center gap-1.5 text-xs font-medium ${statusColor}`}>
                        <StatusIcon className="w-4 h-4" />
                        <span>{t.deployments[project.status as keyof typeof t.deployments] ?? project.status}</span>
                      </div>
                    </div>

                    {project.prompt && (
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2 italic">"{project.prompt}"</p>
                    )}

                    <div className="flex items-center gap-3">
                      {project.preview && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-2 border-white/10 bg-white/5 hover:bg-white/10 text-xs"
                          onClick={() => {
                            const blob = new Blob([project.preview!], { type: "text/html" });
                            const url = URL.createObjectURL(blob);
                            window.open(url, "_blank");
                            setTimeout(() => URL.revokeObjectURL(url), 5000);
                          }}
                          data-testid={`button-view-deployment-${project.id}`}
                        >
                          <ExternalLink className="w-3 h-3" /> View Live
                        </Button>
                      )}
                      <span className="text-xs text-muted-foreground ml-auto font-mono">{project.type}</span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
