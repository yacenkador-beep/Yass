import { Router } from "express";
import { ListTemplatesQueryParams } from "@workspace/api-zod";

const router = Router();

const TEMPLATES = [
  {
    id: "tpl_racing_game",
    name: "Racing Game",
    category: "games",
    description: "A fully playable 2D racing game with tracks, car physics, and lap timing",
    type: "game",
    thumbnail: null,
    tags: ["game", "racing", "2D", "canvas"],
  },
  {
    id: "tpl_ecommerce",
    name: "Ecommerce Store",
    category: "websites",
    description: "Modern ecommerce website with product catalog, cart, and checkout flow",
    type: "website",
    thumbnail: null,
    tags: ["ecommerce", "shop", "react", "tailwind"],
  },
  {
    id: "tpl_food_delivery",
    name: "Food Delivery App",
    category: "apps",
    description: "Food ordering app with restaurant listings, menus, and order tracking",
    type: "app",
    thumbnail: null,
    tags: ["food", "delivery", "mobile", "app"],
  },
  {
    id: "tpl_portfolio",
    name: "Developer Portfolio",
    category: "websites",
    description: "Sleek developer portfolio with projects, skills, and contact sections",
    type: "website",
    thumbnail: null,
    tags: ["portfolio", "personal", "responsive"],
  },
  {
    id: "tpl_saas_landing",
    name: "SaaS Landing Page",
    category: "websites",
    description: "High-converting SaaS landing page with pricing, features, and CTA",
    type: "website",
    thumbnail: null,
    tags: ["saas", "landing", "marketing"],
  },
  {
    id: "tpl_ai_chatbot",
    name: "AI Chatbot",
    category: "apps",
    description: "Intelligent chatbot interface with streaming responses and chat history",
    type: "app",
    thumbnail: null,
    tags: ["ai", "chatbot", "chat", "llm"],
  },
  {
    id: "tpl_platformer",
    name: "Platformer Game",
    category: "games",
    description: "Side-scrolling platformer with player movement, enemies, and collectibles",
    type: "game",
    thumbnail: null,
    tags: ["game", "platformer", "2D", "canvas"],
  },
  {
    id: "tpl_dashboard",
    name: "Admin Dashboard",
    category: "apps",
    description: "Full admin dashboard with charts, tables, user management, and analytics",
    type: "app",
    thumbnail: null,
    tags: ["admin", "dashboard", "analytics", "charts"],
  },
  {
    id: "tpl_blog",
    name: "Blog Platform",
    category: "websites",
    description: "Clean blog with post listings, single post view, categories, and search",
    type: "website",
    thumbnail: null,
    tags: ["blog", "cms", "articles"],
  },
  {
    id: "tpl_mobile_app",
    name: "Mobile App UI",
    category: "apps",
    description: "Complete mobile app UI with onboarding, navigation, and key screens",
    type: "mobile",
    thumbnail: null,
    tags: ["mobile", "app", "ui", "react-native"],
  },
  {
    id: "tpl_python_api",
    name: "Python REST API",
    category: "code",
    description: "Production-ready Python FastAPI with authentication, CRUD, and docs",
    type: "api",
    thumbnail: null,
    tags: ["python", "api", "fastapi", "backend"],
  },
  {
    id: "tpl_shooter_game",
    name: "Shooter Game",
    category: "games",
    description: "Top-down shooter with enemies, bullets, health, and wave-based progression",
    type: "game",
    thumbnail: null,
    tags: ["game", "shooter", "2D", "canvas"],
  },
];

// GET /api/templates
router.get("/templates", (req, res) => {
  const params = ListTemplatesQueryParams.safeParse(req.query);
  let templates = TEMPLATES;

  if (params.data?.category) {
    templates = templates.filter((t) => t.category === params.data!.category);
  }

  return res.json(templates);
});

export default router;
