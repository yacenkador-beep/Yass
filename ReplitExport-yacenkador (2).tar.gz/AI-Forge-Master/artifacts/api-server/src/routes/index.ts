import { Router, type IRouter } from "express";
import healthRouter from "./health";
import aiRouter from "./ai";
import projectsRouter from "./projects";
import templatesRouter from "./templates";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(aiRouter);
router.use(projectsRouter);
router.use(templatesRouter);
router.use(statsRouter);

export default router;
