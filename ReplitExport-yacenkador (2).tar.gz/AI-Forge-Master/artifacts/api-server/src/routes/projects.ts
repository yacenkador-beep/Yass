import { Router, Request, Response, NextFunction } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { projectsTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { ListProjectsQueryParams, CreateProjectBody, GetProjectParams, DeleteProjectParams } from "@workspace/api-zod";
import { randomUUID } from "crypto";

const router = Router();

function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const auth = getAuth(req);
  const userId = (auth?.sessionClaims?.["userId"] as string | undefined) ?? auth?.userId ?? null;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
}

// GET /api/projects
router.get("/projects", requireAuth, async (req: Request, res: Response) => {
  const params = ListProjectsQueryParams.safeParse(req.query);
  const userId = req.userId!;

  try {
    let results = await db
      .select()
      .from(projectsTable)
      .where(eq(projectsTable.userId, userId))
      .orderBy(desc(projectsTable.createdAt))
      .limit(params.data?.limit ?? 50);

    if (params.data?.type) {
      results = results.filter((p) => p.type === params.data!.type);
    }

    res.json(
      results.map((p) => ({
        ...p,
        files: (p.files as Array<{ name: string; content: string; language: string }>) ?? [],
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Error listing projects");
    res.status(500).json({ error: "Failed to list projects" });
  }
});

// POST /api/projects
router.post("/projects", requireAuth, async (req: Request, res: Response) => {
  const parsed = CreateProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const userId = req.userId!;
  const { name, type, prompt, preview, files } = parsed.data;

  try {
    const [project] = await db
      .insert(projectsTable)
      .values({
        id: randomUUID(),
        userId,
        name,
        type,
        status: "ready",
        prompt: prompt ?? null,
        preview: preview ?? null,
        thumbnail: null,
        files: files ?? [],
      })
      .returning();

    res.status(201).json({
      ...project,
      files: [],
      createdAt: project.createdAt.toISOString(),
      updatedAt: project.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Error creating project");
    res.status(500).json({ error: "Failed to create project" });
  }
});

// GET /api/projects/:id
router.get("/projects/:id", requireAuth, async (req: Request, res: Response) => {
  const params = GetProjectParams.safeParse(req.params);
  const userId = req.userId!;

  if (!params.success) {
    res.status(400).json({ error: "Invalid params" });
    return;
  }

  try {
    const [project] = await db
      .select()
      .from(projectsTable)
      .where(and(eq(projectsTable.id, params.data.id), eq(projectsTable.userId, userId)));

    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }

    res.json({
      ...project,
      files: (project.files as Array<{ name: string; content: string; language: string }>) ?? [],
      createdAt: project.createdAt.toISOString(),
      updatedAt: project.updatedAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Error getting project");
    res.status(500).json({ error: "Failed to get project" });
  }
});

// DELETE /api/projects/:id
router.delete("/projects/:id", requireAuth, async (req: Request, res: Response) => {
  const params = DeleteProjectParams.safeParse(req.params);
  const userId = req.userId!;

  if (!params.success) {
    res.status(400).json({ error: "Invalid params" });
    return;
  }

  try {
    await db
      .delete(projectsTable)
      .where(and(eq(projectsTable.id, params.data.id), eq(projectsTable.userId, userId)));

    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error deleting project");
    res.status(500).json({ error: "Failed to delete project" });
  }
});

export default router;
