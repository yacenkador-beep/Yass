import { Router, Request, Response, NextFunction } from "express";
import { getAuth } from "@clerk/express";
import { openai } from "@workspace/integrations-openai-ai-server";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";
import { AiChatBody, AiGenerateCodeBody, AiGenerateImageBody, AiBuildProjectBody } from "@workspace/api-zod";

const router = Router();

function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const auth = getAuth(req);
  const userId = (auth?.sessionClaims?.["userId"] as string | undefined) ?? auth?.userId ?? null;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
}

// POST /api/ai/chat — streaming SSE
router.post("/ai/chat", requireAuth, async (req: Request, res: Response) => {
  const parsed = AiChatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { message, history = [] } = parsed.data;

  const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
    {
      role: "system",
      content:
        "You are Nexus AI, an advanced AI operating system that helps users create apps, games, websites, code, and digital projects. Be helpful, precise, and inspiring. Respond in Markdown when useful.",
    },
    ...history.map((h) => ({
      role: h.role as "user" | "assistant",
      content: h.content,
    })),
    { role: "user", content: message },
  ];

  // Set up SSE streaming
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  const sendEvent = (data: Record<string, unknown>) => {
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-4.1",
      max_completion_tokens: 4096,
      messages,
      stream: true,
    });

    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta?.content;
      if (delta) {
        sendEvent({ type: "token", content: delta });
      }
    }

    sendEvent({ type: "done" });
    res.end();
  } catch (err) {
    req.log.error({ err }, "AI chat streaming error");
    sendEvent({ type: "error", message: "AI service unavailable" });
    res.end();
  }
});

// POST /api/ai/code
router.post("/ai/code", requireAuth, async (req: Request, res: Response) => {
  const parsed = AiGenerateCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { prompt, language = "javascript" } = parsed.data;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4.1",
      max_completion_tokens: 4096,
      messages: [
        {
          role: "system",
          content: `You are an expert programmer. Generate clean, production-ready ${language} code. Return ONLY the code with no markdown fences, just the raw code. Add helpful comments.`,
        },
        { role: "user", content: prompt },
      ],
    });

    const code = completion.choices[0]?.message?.content ?? "// Unable to generate code";
    res.json({ code, language, explanation: null });
  } catch (err) {
    req.log.error({ err }, "AI code generation error");
    res.status(500).json({ error: "AI service unavailable" });
  }
});

// POST /api/ai/image
router.post("/ai/image", requireAuth, async (req: Request, res: Response) => {
  const parsed = AiGenerateImageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { prompt } = parsed.data;

  try {
    const buffer = await generateImageBuffer(prompt, "1024x1024");
    const b64 = buffer.toString("base64");
    const url = `data:image/png;base64,${b64}`;
    res.json({ url, prompt });
  } catch (err) {
    req.log.error({ err }, "AI image generation error");
    res.status(500).json({ error: "AI image service unavailable" });
  }
});

// POST /api/ai/build
router.post("/ai/build", requireAuth, async (req: Request, res: Response) => {
  const parsed = AiBuildProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { prompt, type } = parsed.data;

  const systemPrompt = `You are Nexus AI, an expert project generator. Generate a complete ${type} project based on the user's request.
Return a JSON object with this exact structure:
{
  "summary": "brief description of the project",
  "files": [
    {
      "name": "filename.ext",
      "language": "html|css|javascript|python|etc",
      "content": "complete file content"
    }
  ],
  "preview": "standalone html string for live preview (must be a complete self-contained HTML document with embedded CSS and JS)"
}
Generate complete, working, production-quality code. For web projects include HTML, CSS, and JS files. The preview must be a self-contained HTML document.`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4.1",
      max_completion_tokens: 8192,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Create a ${type}: ${prompt}` },
      ],
    });

    const content = completion.choices[0]?.message?.content ?? "{}";
    let result: { summary?: string; files?: Array<{ name: string; language: string; content: string }>; preview?: string } = {};
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      result = jsonMatch ? (JSON.parse(jsonMatch[0]) as typeof result) : {};
    } catch {
      result = {
        summary: "Project generated successfully",
        files: [{ name: "index.html", language: "html", content: content }],
        preview: content,
      };
    }

    const projectId = `proj_${Date.now()}`;
    res.json({
      projectId,
      files: result.files ?? [],
      preview: result.preview ?? "",
      summary: result.summary ?? null,
    });
  } catch (err) {
    req.log.error({ err }, "AI build error");
    res.status(500).json({ error: "AI service unavailable" });
  }
});

export default router;
