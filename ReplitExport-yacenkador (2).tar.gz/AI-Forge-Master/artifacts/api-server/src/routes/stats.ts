import { Router, Request, Response, NextFunction } from "express";
import { getAuth } from "@clerk/express";
import { db } from "@workspace/db";
import { projectsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const auth = getAuth(req);
  const userId = (auth?.sessionClaims?.["userId"] as string | undefined) ?? auth?.userId ?? null;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  req.userId = userId;
  next();
}

// GET /api/stats/dashboard
router.get("/stats/dashboard", requireAuth, async (req: Request, res: Response) => {
  const userId = req.userId!;

  try {
    const projects = await db
      .select()
      .from(projectsTable)
      .where(eq(projectsTable.userId, userId));

    const totalProjects = projects.length;

    const countByType: Record<string, number> = {};
    for (const p of projects) {
      countByType[p.type] = (countByType[p.type] ?? 0) + 1;
    }

    const generationsByType = Object.entries(countByType).map(([type, count]) => ({
      type,
      count,
    }));

    res.json({
      totalProjects,
      totalGenerations: totalProjects,
      savedTemplates: 12,
      activeDeployments: Math.floor(totalProjects * 0.3),
      generationsByType,
    });
  } catch (err) {
    req.log.error({ err }, "Error getting dashboard stats");
    res.status(500).json({ error: "Failed to get stats" });
  }
});

// GET /api/stats/activity
router.get("/stats/activity", requireAuth, async (req: Request, res: Response) => {
  const userId = req.userId!;

  try {
    const projects = await db
      .select()
      .from(projectsTable)
      .where(eq(projectsTable.userId, userId))
      .orderBy(desc(projectsTable.createdAt))
      .limit(10);

    const activity = projects.map((p) => ({
      id: `act_${p.id}`,
      type: "project_created",
      description: `Created ${p.type} project: "${p.name}"`,
      projectId: p.id,
      projectName: p.name,
      createdAt: p.createdAt.toISOString(),
    }));

    res.json(activity);
  } catch (err) {
    req.log.error({ err }, "Error getting activity");
    res.status(500).json({ error: "Failed to get activity" });
  }
});

export default router;
